import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Users, Phone, Shield, Heart } from 'lucide-react';
import AISearchTab from './components/AISearchTab';
import CommunityWallTab from './components/CommunityWallTab';
import DirectoryTab from './components/DirectoryTab';
import GuidesTab from './components/GuidesTab';
import AlertBanner from './components/AlertBanner';
import TutorialModal from './components/TutorialModal';

type Tab = 'ai-search' | 'community' | 'directory' | 'guides';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('ai-search');
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <div id="app-container" className="min-h-screen bg-gray-50 flex flex-col justify-between font-sans">
      
      {/* Tutorial Modal (Primeros Pasos) */}
      <TutorialModal />

      {/* Global Urgent Alert Banner */}
      <AlertBanner />

      {/* Top Navigation Bar */}
      <header className="bg-white border-b border-gray-100 sticky top-0 z-50 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16 md:h-20">
            {/* Logo / Brand */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-yellow-500 flex items-center justify-center shadow-xs">
                <Heart className="w-5 h-5 text-gray-950 fill-gray-950" />
              </div>
              <div className="text-left">
                <h1 className="text-lg md:text-xl font-bold tracking-tight text-gray-950">Ayuda Venezuela</h1>
                <p className="text-[10px] md:text-xs text-gray-500 font-medium">Plataforma humanitaria de recursos y colaboración</p>
              </div>
            </div>

            {/* Dynamic Connection Indicator */}
            <div className="flex items-center gap-2 bg-gray-50 px-3 py-1.5 rounded-xl border border-gray-100">
              {isOnline ? (
                <>
                  <span className="flex h-2 w-2 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                  <span className="text-[10px] md:text-xs text-emerald-700 font-bold font-mono">Servicio En Línea</span>
                </>
              ) : (
                <>
                  <span className="flex h-2 w-2 relative">
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                  </span>
                  <span className="text-[10px] md:text-xs text-amber-700 font-bold font-mono">Modo Offline Activo</span>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main App Stage */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">
        
        {/* Tab Selection Row */}
        <div className="flex bg-white p-1.5 rounded-2xl border border-gray-100 shadow-xs mb-8 overflow-x-auto gap-1">
          <button
            onClick={() => setActiveTab('ai-search')}
            className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-xs md:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'ai-search'
                ? 'bg-yellow-500 text-gray-950 shadow-sm'
                : 'text-gray-600 hover:text-gray-950 hover:bg-gray-50'
            }`}
          >
            <Sparkles className="w-4 h-4 flex-shrink-0" />
            <span>Asistente Localizador (AI)</span>
          </button>

          <button
            onClick={() => setActiveTab('community')}
            className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-xs md:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'community'
                ? 'bg-yellow-500 text-gray-950 shadow-sm'
                : 'text-gray-600 hover:text-gray-950 hover:bg-gray-50'
            }`}
          >
            <Users className="w-4 h-4 flex-shrink-0" />
            <span>Muro Comunitario</span>
          </button>

          <button
            onClick={() => setActiveTab('directory')}
            className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-xs md:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'directory'
                ? 'bg-yellow-500 text-gray-950 shadow-sm'
                : 'text-gray-600 hover:text-gray-950 hover:bg-gray-50'
            }`}
          >
            <Phone className="w-4 h-4 flex-shrink-0" />
            <span>Directorio de Apoyo</span>
          </button>

          <button
            onClick={() => setActiveTab('guides')}
            className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-xs md:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'guides'
                ? 'bg-yellow-500 text-gray-950 shadow-sm'
                : 'text-gray-600 hover:text-gray-950 hover:bg-gray-50'
            }`}
          >
            <Shield className="w-4 h-4 flex-shrink-0" />
            <span>Guías de Ayuda</span>
          </button>
        </div>

        {/* Tab Panel Render with Staggered Transition */}
        <div className="min-h-[500px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
            >
              {activeTab === 'ai-search' && <AISearchTab />}
              {activeTab === 'community' && <CommunityWallTab />}
              {activeTab === 'directory' && <DirectoryTab />}
              {activeTab === 'guides' && <GuidesTab />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Footer (No slop or telemetry, clean design) */}
      <footer className="bg-white border-t border-gray-100 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left text-xs text-gray-500">
          <p className="font-semibold">Ayuda Venezuela — Conectando personas y recursos esenciales para superar dificultades.</p>
          <div className="flex items-center gap-1.5 justify-center md:justify-end">
            <span>Desarrollado para asistencia humanitaria y apoyo civil</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
