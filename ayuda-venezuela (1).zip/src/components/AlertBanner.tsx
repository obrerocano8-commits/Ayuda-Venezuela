import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  AlertTriangle, 
  Info, 
  AlertOctagon, 
  X, 
  Settings, 
  Save, 
  ToggleLeft, 
  ToggleRight,
  User,
  ShieldAlert,
  XCircle
} from 'lucide-react';
import { db, auth, onAuthStateChanged, User as FirebaseUser } from '../firebase';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { UrgentAlert } from '../types';

export default function AlertBanner() {
  const [alert, setAlert] = useState<UrgentAlert>({
    id: 'global',
    active: false,
    message: '',
    level: 'warning',
    updatedAt: '',
    updatedBy: ''
  });
  
  const [isDismissed, setIsDismissed] = useState(false);
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [isEditOpen, setIsEditOpen] = useState(false);
  
  // Editor form state
  const [formActive, setFormActive] = useState(false);
  const [formMessage, setFormMessage] = useState('');
  const [formLevel, setFormLevel] = useState<'info' | 'warning' | 'critical'>('warning');
  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // 1. Listen to Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
    });
    return () => unsubscribe();
  }, []);

  // 2. Real-time Listen to Firestore /alerts/global
  useEffect(() => {
    const docRef = doc(db, 'alerts', 'global');
    
    // Attempt Firestore subscription
    const unsubscribe = onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data() as UrgentAlert;
        setAlert(data);
        
        // Reset dismissal if alert message or status changed
        const lastDismissed = localStorage.getItem('dismissed_alert_time');
        if (lastDismissed !== data.updatedAt) {
          setIsDismissed(false);
        }
      } else {
        // Default seed alert if document doesn't exist
        const defaultAlert: UrgentAlert = {
          id: 'global',
          active: true,
          message: '⚠️ Alerta de servicios: Reporte de fallas eléctricas temporales en el occidente del país. Se recomienda mantener reservas de agua potable.',
          level: 'warning',
          updatedAt: new Date().toISOString(),
          updatedBy: 'Sistema'
        };
        setAlert(defaultAlert);
      }
    }, (error) => {
      console.warn("Firestore subscription failed, falling back to local simulation:", error);
      
      // Fallback local storage system
      const savedLocal = localStorage.getItem('local_urgent_alert');
      if (savedLocal) {
        try {
          setAlert(JSON.parse(savedLocal));
        } catch (e) {
          console.error(e);
        }
      } else {
        setAlert({
          id: 'global',
          active: true,
          message: '⚠️ Alerta de servicios: Reporte de fallas eléctricas temporales en el occidente del país. Se recomienda mantener reservas de agua potable.',
          level: 'warning',
          updatedAt: new Date().toISOString(),
          updatedBy: 'Sistema'
        });
      }
    });

    return () => unsubscribe();
  }, []);

  // Sync editor fields when alert updates
  useEffect(() => {
    setFormActive(alert.active);
    setFormMessage(alert.message);
    setFormLevel(alert.level);
  }, [alert]);

  const handleDismiss = () => {
    setIsDismissed(true);
    // Mark this specific update timestamp as dismissed
    localStorage.setItem('dismissed_alert_time', alert.updatedAt);
  };

  const handleSaveAlert = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    
    if (!formMessage.trim()) {
      setErrorMessage('El mensaje de la alerta no puede estar vacío.');
      return;
    }

    if (formMessage.length > 1000) {
      setErrorMessage('El mensaje es demasiado largo (máximo 1000 caracteres).');
      return;
    }

    setIsSaving(true);
    const updatedAlert: UrgentAlert = {
      id: 'global',
      active: formActive,
      message: formMessage,
      level: formLevel,
      updatedAt: new Date().toISOString(),
      updatedBy: currentUser?.displayName || currentUser?.email || 'Administrador Comunitario'
    };

    try {
      const docRef = doc(db, 'alerts', 'global');
      await setDoc(docRef, updatedAlert);
      setIsEditOpen(false);
    } catch (error: any) {
      console.error("Error saving alert to Firestore:", error);
      
      // Save locally to localStorage so it works beautifully anyway
      localStorage.setItem('local_urgent_alert', JSON.stringify(updatedAlert));
      setAlert(updatedAlert);
      setIsDismissed(false);
      setIsEditOpen(false);
    } finally {
      setIsSaving(false);
    }
  };

  const getStyleClasses = () => {
    switch (alert.level) {
      case 'critical':
        return {
          bg: 'bg-red-600',
          text: 'text-white',
          icon: <AlertOctagon className="w-5 h-5 text-white animate-bounce" />,
          accent: 'border-red-700 bg-red-700 hover:bg-red-800',
          badge: 'bg-white text-red-700'
        };
      case 'warning':
        return {
          bg: 'bg-yellow-500',
          text: 'text-gray-950',
          icon: <AlertTriangle className="w-5 h-5 text-gray-950 animate-pulse" />,
          accent: 'border-yellow-600 bg-yellow-600 hover:bg-yellow-700',
          badge: 'bg-gray-950 text-yellow-500'
        };
      case 'info':
      default:
        return {
          bg: 'bg-blue-600',
          text: 'text-white',
          icon: <Info className="w-5 h-5 text-white" />,
          accent: 'border-blue-700 bg-blue-700 hover:bg-blue-800',
          badge: 'bg-white text-blue-700'
        };
    }
  };

  const style = getStyleClasses();

  return (
    <div id="urgent-alert-container">
      {/* Alert Banner rendering */}
      <AnimatePresence>
        {alert.active && !isDismissed && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className={`w-full ${style.bg} ${style.text} border-b shadow-sm relative overflow-hidden`}
          >
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between gap-4">
              {/* Left Info Column */}
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className="flex-shrink-0">
                  {style.icon}
                </div>
                <div className="text-left flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-0.5">
                    <span className={`text-[10px] font-extrabold uppercase tracking-widest px-2 py-0.5 rounded-full ${style.badge}`}>
                      {alert.level === 'critical' ? 'Alerta Crítica' : alert.level === 'warning' ? 'Aviso Importante' : 'Información'}
                    </span>
                    <span className="text-[10px] opacity-80 font-mono">
                      Act: {new Date(alert.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-xs md:text-sm font-semibold leading-relaxed truncate md:whitespace-normal">
                    {alert.message}
                  </p>
                </div>
              </div>

              {/* Right Control Buttons */}
              <div className="flex items-center gap-2 flex-shrink-0">
                {/* Admin Gear (Only visible when user is logged in) */}
                {currentUser && (
                  <button
                    onClick={() => setIsEditOpen(true)}
                    className="p-1.5 rounded-lg hover:bg-black/10 transition-all text-current cursor-pointer flex items-center gap-1 text-xs font-bold"
                    title="Editar Alerta Global"
                  >
                    <Settings className="w-4 h-4 animate-spin-slow" />
                    <span className="hidden md:inline">Editar</span>
                  </button>
                )}

                {/* Dismiss Button */}
                <button
                  onClick={handleDismiss}
                  className="p-1.5 rounded-lg hover:bg-black/10 transition-all text-current cursor-pointer"
                  title="Ocultar"
                >
                  <X className="w-4.5 h-4.5" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Admin Floating indicator when alert is NOT active but user IS logged in */}
      {currentUser && !alert.active && (
        <div className="bg-gray-100 border-b border-gray-200 text-gray-700 py-1.5 text-xs text-center font-semibold flex items-center justify-center gap-2">
          <span>El banner de alerta global está inactivo.</span>
          <button
            onClick={() => setIsEditOpen(true)}
            className="text-yellow-600 hover:text-yellow-700 underline font-bold cursor-pointer"
          >
            Activar Alerta de Emergencia
          </button>
        </div>
      )}

      {/* Alert Edit Modal / Drawer */}
      <AnimatePresence>
        {isEditOpen && (
          <div className="fixed inset-0 bg-black/60 z-[999] flex items-center justify-center p-4 backdrop-blur-xs">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl p-6 max-w-lg w-full border border-gray-100 shadow-2xl space-y-5 text-gray-900"
            >
              {/* Modal Header */}
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                  <div className="p-2.5 bg-yellow-100 rounded-xl text-yellow-800">
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-950 text-base">Control de Alerta Global</h3>
                    <p className="text-gray-500 text-xs">Modifica la información que ven todos los usuarios</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsEditOpen(false)}
                  className="p-1.5 text-gray-400 hover:text-gray-600 rounded-lg cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {errorMessage && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
                  <XCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Form */}
              <form onSubmit={handleSaveAlert} className="space-y-4 text-left">
                {/* Active Toggle */}
                <div className="flex justify-between items-center bg-gray-50 p-3 rounded-2xl border border-gray-100">
                  <div>
                    <h4 className="text-xs font-bold text-gray-800">Estado de Alerta</h4>
                    <p className="text-gray-500 text-[10px]">Indica si la alerta debe mostrarse u ocultarse globalmente</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFormActive(!formActive)}
                    className="text-gray-700 cursor-pointer"
                  >
                    {formActive ? (
                      <ToggleRight className="w-12 h-8 text-yellow-500" />
                    ) : (
                      <ToggleLeft className="w-12 h-8 text-gray-400" />
                    )}
                  </button>
                </div>

                {/* Alert Level Select */}
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                    Nivel de Crítica/Peligro
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setFormLevel('info')}
                      className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all cursor-pointer text-center ${
                        formLevel === 'info'
                          ? 'bg-blue-50 border-blue-500 text-blue-700 ring-2 ring-blue-100'
                          : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      Info (Azul)
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormLevel('warning')}
                      className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all cursor-pointer text-center ${
                        formLevel === 'warning'
                          ? 'bg-yellow-50 border-yellow-500 text-yellow-800 ring-2 ring-yellow-100'
                          : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      Aviso (Amarillo)
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormLevel('critical')}
                      className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all cursor-pointer text-center ${
                        formLevel === 'critical'
                          ? 'bg-red-50 border-red-500 text-red-700 ring-2 ring-red-100'
                          : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      Crítico (Rojo)
                    </button>
                  </div>
                </div>

                {/* Message input */}
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                    Mensaje de la Alerta / Aviso
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Describe detalladamente el aviso, falla de servicio, número de emergencia, etc. Sé breve y preciso."
                    value={formMessage}
                    onChange={(e) => setFormMessage(e.target.value)}
                    required
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500 text-gray-900"
                  />
                  <span className="text-[10px] text-gray-400 mt-1 block text-right font-mono">
                    {formMessage.length}/1000 caracteres
                  </span>
                </div>

                {/* Footer buttons */}
                <div className="flex gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsEditOpen(false)}
                    className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold py-2.5 rounded-xl text-xs transition-all cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="flex-1 bg-yellow-500 hover:bg-yellow-600 disabled:bg-gray-200 text-gray-950 font-bold py-2.5 rounded-xl text-xs transition-all flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isSaving ? 'Guardando...' : 'Guardar y Aplicar'}</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
