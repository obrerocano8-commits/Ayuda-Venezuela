import React, { useState, useEffect } from 'react';
import { GuideItem } from '../types';
import { Shield, Droplet, Zap, Heart, CheckCircle2, ChevronRight, ChevronDown, Download, Check, CloudLightning } from 'lucide-react';

const GUIDES: GuideItem[] = [
  {
    id: 'g1',
    title: 'Purificación de Agua en el Hogar',
    description: 'Métodos caseros efectivos para potabilizar agua no tratada o proveniente de cisternas en situaciones de escasez.',
    category: 'Salud',
    steps: [
      'Filtrado inicial: Pasa el agua a través de un paño limpio o filtro de café para eliminar sedimentos visibles.',
      'Hervido eficaz: Lleva el agua a un punto de ebullición fuerte (burbujeo constante) por un mínimo de 3 a 5 minutos.',
      'Cloración (si no se puede hervir): Agrega exactamente 2 a 4 gotas de cloro comercial sin aroma (concentración del 5.25%) por cada litro de agua.',
      'Reposo de desinfección: Mezcla bien el agua clorada y déjala reposar destapada o semicubierta durante 30 minutos antes de consumirla.',
      'Método SODIS (Solar): Llena botellas plásticas transparentes limpias y colócalas en posición horizontal bajo el sol directo durante 6 horas continuas para que los rayos UV destruyan patógenos.'
    ]
  },
  {
    id: 'g2',
    title: 'Prevención ante Cortes Eléctricos Prolongados',
    description: 'Protocolos de seguridad física, cuidado de electrodomésticos y preservación de alimentos durante fluctuaciones o racionamientos.',
    category: 'Electricidad & Agua',
    steps: [
      'Desconexión preventiva: Ante un corte, desconecta de inmediato neveras, aires acondicionados y equipos costosos para protegerlos del pico de voltaje al retornar la luz.',
      'Preservación de frío: Mantén las puertas de la nevera y el congelador cerradas el mayor tiempo posible. Una nevera cerrada mantiene el frío por 4 horas; un congelador lleno por 48 horas.',
      'Iluminación segura: Prioriza el uso de linternas LED, luces recargables o velas colocadas sobre bases anchas de cerámica o metal, nunca cerca de cortinas.',
      'Carga estratégica: Mantén baterías externas (powerbanks) cargadas al 100% en todo momento. Pon tus teléfonos en modo "Ahorro de energía" o de avión durante el corte.',
      'Almacenamiento térmico: Si cuentas con servicio intermitente, congela botellas de agua para que actúen como bloques de hielo dentro del refrigerador durante las horas de apagón.'
    ]
  },
  {
    id: 'g3',
    title: 'Kit de Emergencia Médica Esencial',
    description: 'Lista recomendada de insumos médicos básicos y medicamentos de venta libre recomendados para mantener en el hogar.',
    category: 'Salud',
    steps: [
      'Materiales de cura: Gasas estériles, vendas adhesivas (curitas), vendas elásticas de compresión, algodón y adhesivo médico de micropore.',
      'Antisépticos: Alcohol al 70%, agua oxigenada, solución fisiológica para lavado de heridas y jabón neutro.',
      'Medicamentos de control sintomático: Acetaminofén (paracetamol) o Ibuprofeno para dolor y fiebre, antiespasmódicos e hidratantes orales.',
      'Suero Oral: Sobres de sales de rehidratación oral para tratar diarreas, deshidrataciones o golpes de calor.',
      'Instrumentos útiles: Termómetro digital de axila, tijeras de punta roma, pinzas desinfectadas y guantes desechables de látex o nitrilo.'
    ]
  },
  {
    id: 'g4',
    title: 'Derechos Ciudadanos en Controles Policiales',
    description: 'Guía informativa redactada según la Constitución venezolana para conocer tus derechos civiles básicos durante retenciones o alcabalas.',
    category: 'Derechos & Legal',
    steps: [
      'Identificación obligatoria: Los funcionarios policiales deben portar su credencial visible, uniforme reglamentario con su nombre expuesto y justificar el motivo del control.',
      'Derecho a la integridad física: La Constitución prohíbe tratos crueles, inhumanos o degradantes. Ningún oficial puede agredirte física o verbalmente.',
      'Derecho a la propiedad: Los funcionarios no están autorizados a retener tus documentos de identidad originales de forma indefinida, ni a confiscar teléfonos o dinero sin orden judicial.',
      'Grabación del procedimiento: Tienes derecho constitucional a grabar en video o audio los procedimientos de seguridad ciudadana realizados en la vía pública.',
      'Derecho de menores: Los menores de edad no pueden ser interrogados ni retenidos en alcabalas sin la presencia obligatoria de sus padres o representantes legales.'
    ]
  }
];

export default function GuidesTab() {
  const [openGuideId, setOpenGuideId] = useState<string | null>('g1');
  const [downloadedIds, setDownloadedIds] = useState<string[]>([]);

  useEffect(() => {
    // Load downloaded guide states from localStorage
    const saved = localStorage.getItem('downloaded_guides');
    if (saved) {
      try {
        setDownloadedIds(JSON.parse(saved));
      } catch (e) {
        console.error("Error parsing downloaded guides:", e);
      }
    }
  }, []);

  const toggleDownload = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    let updated: string[];
    if (downloadedIds.includes(id)) {
      updated = downloadedIds.filter(x => x !== id);
    } else {
      updated = [...downloadedIds, id];
    }
    setDownloadedIds(updated);
    localStorage.setItem('downloaded_guides', JSON.stringify(updated));
  };

  const toggleGuide = (id: string) => {
    setOpenGuideId(openGuideId === id ? null : id);
  };

  const getIcon = (category: string) => {
    switch (category) {
      case 'Salud':
        return <Heart className="w-5 h-5 text-red-500" />;
      case 'Electricidad & Agua':
        return <Zap className="w-5 h-5 text-yellow-500" />;
      case 'Derechos & Legal':
        return <Shield className="w-5 h-5 text-blue-500" />;
      default:
        return <Droplet className="w-5 h-5 text-teal-500" />;
    }
  };

  return (
    <div id="guides-tab" className="space-y-6">
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-bold text-gray-950 mb-2">Guías de Supervivencia y Asistencia</h2>
        <p className="text-gray-600 text-sm">
          Guías prácticas elaboradas por especialistas con instrucciones paso a paso para afrontar interrupciones de servicios públicos, emergencias de salud o hacer valer tus derechos civiles en Venezuela.
        </p>
      </div>

      <div className="space-y-4">
        {GUIDES.map((guide) => {
          const isOpen = openGuideId === guide.id;
          return (
            <div
              key={guide.id}
              className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden transition-all duration-200"
            >
              {/* Header */}
              <button
                onClick={() => toggleGuide(guide.id)}
                className="w-full text-left p-5 flex items-start gap-4 hover:bg-gray-50/50 transition-all cursor-pointer"
              >
                <div className="p-2.5 bg-gray-50 rounded-xl border border-gray-100 flex-shrink-0">
                  {getIcon(guide.category)}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold text-gray-500 bg-gray-100 px-2 py-0.5 rounded-md">
                      {guide.category}
                    </span>
                    {downloadedIds.includes(guide.id) && (
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md flex items-center gap-1 border border-emerald-100">
                        <Check className="w-3 h-3 text-emerald-600" />
                        Acceso Offline
                      </span>
                    )}
                  </div>
                  <h3 className="font-bold text-gray-950 text-base md:text-lg mb-1">{guide.title}</h3>
                  <p className="text-gray-600 text-xs md:text-sm line-clamp-2 md:line-clamp-none">
                    {guide.description}
                  </p>
                </div>

                <div className="flex-shrink-0 self-center text-gray-400">
                  {isOpen ? (
                    <ChevronDown className="w-5 h-5" />
                  ) : (
                    <ChevronRight className="w-5 h-5" />
                  )}
                </div>
              </button>

              {/* Content Steps */}
              {isOpen && (
                <div className="px-5 pb-6 pt-2 border-t border-gray-50 bg-gray-50/30">
                  <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">
                    Instrucciones Paso a Paso
                  </h4>
                  
                  <div className="space-y-4">
                    {guide.steps.map((step, index) => (
                      <div key={index} className="flex gap-3 items-start">
                        <div className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-full bg-yellow-100 text-yellow-800 text-xs font-bold font-mono border border-yellow-200 mt-0.5">
                          {index + 1}
                        </div>
                        <p className="text-gray-700 text-xs md:text-sm leading-relaxed">
                          {step}
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-yellow-50/60 border border-yellow-100 rounded-2xl text-yellow-950">
                    <div className="flex items-start gap-2.5 text-xs text-yellow-900">
                      <CheckCircle2 className="w-4.5 h-4.5 flex-shrink-0 mt-0.5 text-yellow-600" />
                      <div>
                        <span className="font-bold block mb-0.5 text-gray-900">Disponible Sin Conexión</span>
                        <span>Esta guía está registrada en el Service Worker. Se puede consultar plenamente si te quedas sin acceso a Internet.</span>
                      </div>
                    </div>
                    
                    <button
                      onClick={(e) => toggleDownload(guide.id, e)}
                      className={`flex-shrink-0 flex items-center justify-center gap-1.5 font-bold text-xs px-3.5 py-2 rounded-xl border transition-all cursor-pointer ${
                        downloadedIds.includes(guide.id)
                          ? 'bg-emerald-600 border-emerald-600 text-white hover:bg-emerald-700'
                          : 'bg-white border-gray-200 text-gray-800 hover:bg-gray-50'
                      }`}
                    >
                      {downloadedIds.includes(guide.id) ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Guardada Offline</span>
                        </>
                      ) : (
                        <>
                          <Download className="w-3.5 h-3.5 animate-pulse" />
                          <span>Guardar Offline</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="mt-4 flex items-center gap-2 p-3 bg-gray-50 border border-gray-200/60 rounded-xl text-gray-600 text-xs">
                    <CloudLightning className="w-4 h-4 flex-shrink-0 text-gray-400" />
                    <span>Esta información es puramente educativa e informativa. Comparte esta guía con familiares o vecinos imprimiéndola o enviándola por mensajería.</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
