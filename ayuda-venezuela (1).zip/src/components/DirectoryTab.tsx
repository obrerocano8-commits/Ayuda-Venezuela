import React, { useState, useEffect } from 'react';
import { EmergencyContact, CommunityReport } from '../types';
import { Phone, ExternalLink, Copy, Check, Search, Filter, MapPin, Heart, List, Map as MapIcon, Users, AlertTriangle, Plus, ShieldCheck, HelpCircle, Clock } from 'lucide-react';
import InteractiveMap from './InteractiveMap';
import NovedadesSection from './NovedadesSection';
import { useRealtimeStatuses } from '../hooks/useRealtimeStatuses';
import { collection, query, where, onSnapshot, doc, setDoc } from 'firebase/firestore';
import { db, auth } from '../firebase';

export const CONTACTS: EmergencyContact[] = [
  {
    id: '1',
    name: 'Cruz Roja Venezolana',
    description: 'Asistencia médica de emergencia, banco de sangre, programas de socorro y respuesta humanitaria.',
    phone: '+58 212-578-2187',
    category: 'Salud',
    location: 'Sede Central Caracas',
    state: 'Nacional',
    website: 'http://www.cruzrojavenezolana.org',
    lat: 10.4806,
    lng: -66.9036
  },
  {
    id: '2',
    name: 'Cáritas de Venezuela',
    description: 'Programa SAMAN de nutrición infantil, entrega de alimentos, medicamentos, y apoyo a comunidades vulnerables.',
    phone: '+58 212-481-0504',
    category: 'Alimentos',
    location: 'Nivel Nacional',
    state: 'Nacional',
    website: 'http://caritasvenezuela.org',
    lat: 10.4910,
    lng: -66.8900
  },
  {
    id: '3',
    name: 'Foro Penal (Asistencia Legal)',
    description: 'Asistencia y defensa legal gratuita para personas detenidas arbitrariamente y víctimas de violaciones de DDHH.',
    phone: '+58 412-556-8201',
    category: 'Ayuda Legal',
    location: 'Nivel Nacional - Emergencias 24/7',
    state: 'Nacional',
    website: 'https://foropenal.com',
    lat: 10.4850,
    lng: -66.8600
  },
  {
    id: '4',
    name: 'Acción Solidaria',
    description: 'Centro de Información Nacional de VIH/Sida y enfermedades crónicas. Banco de medicamentos y asesoría médica.',
    phone: '+58 212-952-9554',
    category: 'Salud',
    location: 'Caracas (Envíos nacionales)',
    state: 'Caracas',
    website: 'https://www.accionsolidaria.info',
    lat: 10.4880,
    lng: -66.8350
  },
  {
    id: '5',
    name: 'Bomberos Metropolitanos de Caracas',
    description: 'Cuerpo de bomberos principal para atención de incendios, rescates y emergencias civiles.',
    phone: '+58 212-545-4545',
    category: 'Servicios',
    location: 'Caracas',
    state: 'Caracas',
    lat: 10.5060,
    lng: -66.9140
  },
  {
    id: '6',
    name: 'PROVEA (Programa Venezolano de Educación-Acción en DDHH)',
    description: 'Asesoría jurídica gratuita, documentación y defensa de derechos económicos, sociales y culturales.',
    phone: '+58 212-860-6667',
    category: 'Ayuda Legal',
    location: 'Nivel Nacional',
    state: 'Nacional',
    website: 'https://provea.org',
    lat: 10.5010,
    lng: -66.9180
  },
  {
    id: '7',
    name: 'Dividendo Voluntario para la Comunidad (DVC)',
    description: 'Programas de alimentación escolar, comedores comunitarios y salud preventiva para niños y madres.',
    phone: '+58 212-953-2286',
    category: 'Alimentos',
    location: 'Nivel Nacional',
    state: 'Nacional',
    website: 'https://www.dividendovoluntario.org',
    lat: 10.4940,
    lng: -66.8650
  },
  {
    id: '8',
    name: 'SenosAyuda',
    description: 'Organización de apoyo integral a pacientes con cáncer de mama, mamografías a bajo costo y orientación.',
    phone: '+58 212-993-9892',
    category: 'Salud',
    location: 'Caracas / Nacional',
    state: 'Caracas',
    website: 'https://senosayuda.org.ve',
    lat: 10.4720,
    lng: -66.8530
  },
  {
    id: '9',
    name: 'Protección Civil y Administración de Desastres',
    description: 'Coordinación nacional para emergencias por lluvias, desastres naturales y ayuda humanitaria de rescate.',
    phone: '+58 212-631-1507',
    category: 'Servicios',
    location: 'Nivel Nacional',
    state: 'Nacional',
    lat: 10.4820,
    lng: -66.8850
  },
  // Zulia
  {
    id: '10',
    name: 'Bomberos de Maracaibo',
    description: 'Atención médica y servicio de extinción de incendios de emergencia en la capital zuliana.',
    phone: '+58 261-723-1111',
    category: 'Servicios',
    location: 'Maracaibo',
    state: 'Zulia',
    lat: 10.6380,
    lng: -71.6250
  },
  {
    id: '11',
    name: 'Cáritas Diócesis de Maracaibo',
    description: 'Programas de olla comunitaria, atención médica primaria y banco de medicamentos para comunidades de Zulia.',
    phone: '+58 261-722-5444',
    category: 'Alimentos',
    location: 'Maracaibo',
    state: 'Zulia',
    lat: 10.6550,
    lng: -71.6050
  },
  // Lara
  {
    id: '12',
    name: 'Bomberos de Iribarren (Barquisimeto)',
    description: 'Servicios de emergencia, rescate and control de incendios en el estado Lara.',
    phone: '+58 251-231-4444',
    category: 'Servicios',
    location: 'Barquisimeto',
    state: 'Lara',
    lat: 10.0710,
    lng: -69.3250
  },
  {
    id: '13',
    name: 'Cruz Roja Sub-Comité Lara',
    description: 'Atención de salud primaria, despistajes médicos e iniciativas de ayuda comunitaria larense.',
    phone: '+58 251-254-1122',
    category: 'Salud',
    location: 'Barquisimeto',
    state: 'Lara',
    lat: 10.0650,
    lng: -69.3520
  },
  // Carabobo
  {
    id: '14',
    name: 'Bomberos de Valencia',
    description: 'Atención rápida de emergencias viales, incendios y atención prehospitalaria en el estado Carabobo.',
    phone: '+58 241-832-1111',
    category: 'Servicios',
    location: 'Valencia',
    state: 'Carabobo',
    lat: 10.1550,
    lng: -68.0120
  },
  {
    id: '15',
    name: 'Cruz Roja Seccional Carabobo',
    description: 'Hospital clínico Cruz Roja en Valencia con servicios médicos especializados y programas sociales.',
    phone: '+58 241-821-4567',
    category: 'Salud',
    location: 'Valencia',
    state: 'Carabobo',
    lat: 10.1810,
    lng: -67.9890
  },
  // Mérida
  {
    id: '16',
    name: 'Bomberos del Estado Mérida',
    description: 'Atención de emergencias civiles, forestales y rescate de montaña en la región andina de Mérida.',
    phone: '+58 274-263-1111',
    category: 'Servicios',
    location: 'Mérida',
    state: 'Mérida',
    lat: 8.5850,
    lng: -71.1600
  },
  {
    id: '17',
    name: 'Grupo de Rescate Mérida',
    description: 'Búsqueda y salvamento voluntario de montaña, atención de desastres y primeros auxilios en Mérida.',
    phone: '+58 274-252-4444',
    category: 'Servicios',
    location: 'Mérida',
    state: 'Mérida',
    lat: 8.6020,
    lng: -71.1350
  },
  // Táchira
  {
    id: '18',
    name: 'Bomberos de San Cristóbal',
    description: 'Servicio de ambulancia de emergencia, control de siniestros y rescate técnico en Táchira.',
    phone: '+58 276-343-4444',
    category: 'Servicios',
    location: 'San Cristóbal',
    state: 'Táchira',
    lat: 7.7550,
    lng: -72.2150
  },
  {
    id: '19',
    name: 'Cruz Roja Seccional Táchira',
    description: 'Suministros médicos, programas de agua y saneamiento básico y asistencia en zonas fronterizas.',
    phone: '+58 276-341-2345',
    category: 'Salud',
    location: 'San Cristóbal',
    state: 'Táchira',
    lat: 7.7720,
    lng: -72.2350
  },
  // Bolívar
  {
    id: '20',
    name: 'Cruz Roja Seccional Bolívar',
    description: 'Atención de salud de emergencia, capacitación comunitaria y socorro en la región de Guayana.',
    phone: '+58 285-632-1122',
    category: 'Salud',
    location: 'Ciudad Bolívar',
    state: 'Bolívar',
    lat: 8.1250,
    lng: -63.5350
  },
  // Anzoátegui
  {
    id: '21',
    name: 'Bomberos de Barcelona',
    description: 'Prevención y combate de incendios, rescates y traslados de emergencia en la zona norte de Anzoátegui.',
    phone: '+58 281-274-1111',
    category: 'Servicios',
    location: 'Barcelona',
    state: 'Anzoátegui',
    lat: 10.1280,
    lng: -64.6920
  }
];

const VENEZUELA_STATES = [
  { value: 'All', label: 'Todos los Estados / Nacional' },
  { value: 'Nacional', label: 'Nivel Nacional' },
  { value: 'Caracas', label: 'Caracas (Distrito Capital)' },
  { value: 'Anzoátegui', label: 'Anzoátegui' },
  { value: 'Bolívar', label: 'Bolívar' },
  { value: 'Carabobo', label: 'Carabobo' },
  { value: 'Lara', label: 'Lara' },
  { value: 'Mérida', label: 'Mérida' },
  { value: 'Táchira', label: 'Táchira' },
  { value: 'Zulia', label: 'Zulia' }
];

export default function DirectoryTab() {
  const { statuses } = useRealtimeStatuses();
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedState, setSelectedState] = useState<string>('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showOnlyFavorites, setShowOnlyFavorites] = useState(false);

  // Missing Persons Realtime States
  const [missingPersons, setMissingPersons] = useState<CommunityReport[]>([]);
  const [missingSearch, setMissingSearch] = useState('');
  const [isLoadingMissing, setIsLoadingMissing] = useState(true);
  const [isMissingFormOpen, setIsMissingFormOpen] = useState(false);

  // Missing Persons Form Fields
  const [missingName, setMissingName] = useState('');
  const [missingAge, setMissingAge] = useState('');
  const [missingLastSeen, setMissingLastSeen] = useState('');
  const [missingDetails, setMissingDetails] = useState('');
  const [missingContact, setMissingContact] = useState('');
  const [missingReporterName, setMissingReporterName] = useState('');
  const [missingFormError, setMissingFormError] = useState('');
  const [isSubmittingMissing, setIsSubmittingMissing] = useState(false);

  // Fetch missing persons in real-time
  useEffect(() => {
    const q = query(
      collection(db, 'reports'),
      where('category', '==', 'missing_person')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: CommunityReport[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data();
        items.push({ id: docSnap.id, ...data } as CommunityReport);
      });
      // Sort by newest
      items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setMissingPersons(items);
      setIsLoadingMissing(false);
    }, (error) => {
      console.error("Error loading missing persons:", error);
      setIsLoadingMissing(false);
    });

    return () => unsubscribe();
  }, []);

  const handleSubmitMissing = async (e: React.FormEvent) => {
    e.preventDefault();
    setMissingFormError('');

    if (!missingName.trim()) {
      setMissingFormError('El nombre completo es requerido.');
      return;
    }
    if (!missingLastSeen.trim()) {
      setMissingFormError('El último lugar o zona donde fue visto es requerido.');
      return;
    }
    if (!missingContact.trim()) {
      setMissingFormError('La información de contacto de los familiares es requerida.');
      return;
    }
    if (missingDetails.length < 10) {
      setMissingFormError('Por favor, describe los rasgos o detalles de la persona en al menos 10 caracteres.');
      return;
    }

    setIsSubmittingMissing(true);
    try {
      const reportsCol = collection(db, 'reports');
      const newRef = doc(reportsCol);
      const reportId = newRef.id;

      const titleVal = `Alerta de Desaparición: ${missingName.trim()} (${missingAge.trim() ? missingAge.trim() + ' años' : 'Edad desconocida'})`;
      const descVal = `ÚLTIMA VEZ VISTO: ${missingLastSeen.trim()}\n\nSEÑAS PARTICULARES & DETALLES:\n${missingDetails.trim()}`;

      const user = auth.currentUser;
      const authorNameValue = user ? (user.displayName || 'Familiar de Apoyo') : (missingReporterName.trim() || 'Familiar / Ciudadano');
      const authorPhotoValue = user ? (user.photoURL || 'https://www.gravatar.com/avatar?d=mp') : 'https://www.gravatar.com/avatar?d=mp';
      const userIdValue = user ? user.uid : 'guest';

      const newReport: CommunityReport = {
        id: reportId,
        userId: userIdValue,
        authorName: authorNameValue,
        authorPhoto: authorPhotoValue,
        title: titleVal,
        description: descVal,
        type: 'need',
        category: 'missing_person',
        location: missingLastSeen.trim(),
        contactInfo: missingContact.trim(),
        createdAt: new Date().toISOString(),
        likesCount: 0
      };

      await setDoc(newRef, newReport);

      // Reset form
      setMissingName('');
      setMissingAge('');
      setMissingLastSeen('');
      setMissingDetails('');
      setMissingContact('');
      setMissingReporterName('');
      setIsMissingFormOpen(false);
      alert('Alerta de desaparición publicada con éxito en la plataforma.');
    } catch (err: any) {
      console.error("Error creating missing person report:", err);
      setMissingFormError(`Error al publicar reporte: ${err.message}`);
    } finally {
      setIsSubmittingMissing(false);
    }
  };

  // Favorites tracking initialized with localStorage
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('ayuda_venezuela_favorite_contacts');
      return saved ? JSON.parse(saved) : [];
    } catch (err) {
      console.error("Error reading favorites from localStorage:", err);
      return [];
    }
  });

  const toggleFavorite = (id: string) => {
    setFavorites(prev => {
      const isAlreadyFav = prev.includes(id);
      const newFavs = isAlreadyFav ? prev.filter(fId => fId !== id) : [...prev, id];
      try {
        localStorage.setItem('ayuda_venezuela_favorite_contacts', JSON.stringify(newFavs));
      } catch (err) {
        console.error("Error writing favorites to localStorage:", err);
      }
      return newFavs;
    });
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredContacts = CONTACTS.filter(contact => {
    const matchesSearch = 
      contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (contact.location && contact.location.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'All' || contact.category === selectedCategory;
    const matchesState = selectedState === 'All' || contact.state === selectedState;
    const matchesFavorites = !showOnlyFavorites || favorites.includes(contact.id);
    
    return matchesSearch && matchesCategory && matchesState && matchesFavorites;
  });

  const filteredMissing = missingPersons.filter(person => {
    const term = missingSearch.toLowerCase();
    return (
      person.title.toLowerCase().includes(term) ||
      person.description.toLowerCase().includes(term) ||
      person.location.toLowerCase().includes(term)
    );
  });

  const categories = ['All', 'Salud', 'Alimentos', 'Servicios', 'Ayuda Legal'];

  return (
    <div id="directory-tab" className="space-y-6">
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-bold text-gray-950 mb-2">Directorio de Emergencia y Apoyo</h2>
        <p className="text-gray-600 text-sm">
          Accede rápidamente a números telefónicos, direcciones y portales web de organizaciones de primera necesidad y ayuda humanitaria que prestan servicio activo en Venezuela.
        </p>
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mt-6 pt-6 border-t border-gray-100">
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-2 p-2 px-3 bg-emerald-50 border border-emerald-100 rounded-xl text-emerald-800 text-xs inline-flex">
              <Check className="w-4 h-4 flex-shrink-0 text-emerald-600" />
              <span className="font-semibold">Sincronizado Offline — Acceso garantizado</span>
            </div>
            
            <div className="flex items-center gap-2 p-2 px-3 bg-red-50 border border-red-100 rounded-xl text-red-800 text-xs inline-flex">
              <Heart className="w-4 h-4 flex-shrink-0 text-red-600 fill-red-100" />
              <span className="font-semibold">Soporta favoritos offline</span>
            </div>
          </div>

          {/* Segmented Control Switcher for List vs Interactive Map */}
          <div className="flex bg-gray-100 p-1 rounded-xl self-start md:self-auto border border-gray-200">
            <button
              onClick={() => setViewMode('list')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'list'
                  ? 'bg-white text-gray-950 shadow-xs'
                  : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Ver Lista</span>
            </button>
            <button
              onClick={() => setViewMode('map')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'map'
                  ? 'bg-white text-gray-950 shadow-xs'
                  : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              <MapIcon className="w-3.5 h-3.5 text-yellow-500" />
              <span>Ver Mapa</span>
            </button>
          </div>
        </div>
      </div>

      {viewMode === 'map' ? (
        <InteractiveMap contacts={CONTACTS} realtimeStatuses={statuses} />
      ) : (
        <>
          {/* Quick Access Favorites Bar */}
          {favorites.length > 0 && (
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
              <h4 className="text-[11px] font-extrabold text-red-600 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                <Heart className="w-3.5 h-3.5 fill-red-500 text-red-500" />
                <span>Acceso Rápido Offline — Contactos Guardados</span>
              </h4>
              <div className="flex flex-wrap gap-2">
                {CONTACTS.filter(c => favorites.includes(c.id)).map(favContact => (
                  <button
                    key={`quick-fav-${favContact.id}`}
                    onClick={() => {
                      setSearchTerm(favContact.name);
                      setSelectedCategory('All');
                      setSelectedState('All');
                      setShowOnlyFavorites(false);
                    }}
                    className="bg-red-50/40 hover:bg-red-50 border border-red-100/60 px-3 py-1.5 rounded-xl text-xs font-semibold text-gray-800 transition-all cursor-pointer flex items-center gap-2 shadow-2xs hover:scale-102"
                  >
                    <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
                    <span className="truncate max-w-[120px]">{favContact.name}</span>
                    <span className="text-gray-400 text-[10px] font-mono font-normal">({favContact.phone})</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Search & Filters */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-4">
            <div className="flex flex-col md:flex-row gap-4">
              {/* Search Input */}
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Buscar organización, servicio o ubicación..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:bg-white transition-all text-gray-900"
                />
              </div>

              {/* Dropdown for State/Region */}
              <div className="relative w-full md:w-72">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 flex items-center">
                  <MapPin className="w-4 h-4 text-gray-400" />
                </span>
                <select
                  value={selectedState}
                  onChange={(e) => setSelectedState(e.target.value)}
                  className="w-full pl-10 pr-10 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:bg-white transition-all text-gray-900 font-semibold cursor-pointer"
                >
                  {VENEZUELA_STATES.map(st => (
                    <option key={st.value} value={st.value}>
                      {st.label}
                    </option>
                  ))}
                </select>
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none text-xs">
                  ▼
                </span>
              </div>
            </div>
            
            {/* Category Chips and Favorites Filter Button */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-gray-100">
              <div className="flex flex-wrap gap-2 items-center">
                <span className="text-xs font-bold text-gray-400 uppercase tracking-wider mr-1">Categoría:</span>
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap border transition-all cursor-pointer ${
                      selectedCategory === cat
                        ? 'bg-yellow-500 border-yellow-500 text-gray-950 shadow-sm'
                        : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    {cat === 'All' ? 'Todas' : cat}
                  </button>
                ))}
              </div>

              <button
                onClick={() => setShowOnlyFavorites(prev => !prev)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                  showOnlyFavorites
                    ? 'bg-red-500 border-red-500 text-white shadow-sm hover:bg-red-600'
                    : 'bg-red-50/50 border-red-100 text-red-600 hover:bg-red-50'
                }`}
              >
                <Heart className={`w-3.5 h-3.5 ${showOnlyFavorites ? 'fill-white text-white' : 'fill-red-500 text-red-500'}`} />
                <span>Ver Guardados</span>
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${showOnlyFavorites ? 'bg-white/20 text-white' : 'bg-red-100 text-red-700'}`}>
                  {favorites.length}
                </span>
              </button>
            </div>
          </div>

          {/* Grid of contacts */}
          {filteredContacts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredContacts.map(contact => {
                const isFav = favorites.includes(contact.id);
                return (
                  <div
                    key={contact.id}
                    className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm flex flex-col justify-between hover:border-yellow-200 transition-all relative overflow-hidden"
                  >
                    <div>
                      <div className="flex justify-between items-start gap-2 mb-2 flex-wrap">
                        <div className="flex gap-1.5 items-center">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            contact.category === 'Salud' ? 'bg-red-50 text-red-700 border border-red-100' :
                            contact.category === 'Alimentos' ? 'bg-green-50 text-green-700 border border-green-100' :
                            contact.category === 'Ayuda Legal' ? 'bg-blue-50 text-blue-700 border border-blue-100' :
                            'bg-amber-50 text-amber-700 border border-amber-100'
                          }`}>
                            {contact.category}
                          </span>
                          
                          {statuses[contact.id] && (
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold flex items-center gap-1 border ${
                              statuses[contact.id].status === 'Activo' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                              statuses[contact.id].status === 'Sin insumos' ? 'bg-amber-50 text-amber-700 border-amber-100' :
                              'bg-red-50 text-red-700 border-red-100'
                            }`}>
                              <span className={`inline-block w-1.5 h-1.5 rounded-full ${
                                statuses[contact.id].status === 'Activo' ? 'bg-emerald-500 animate-pulse' :
                                statuses[contact.id].status === 'Sin insumos' ? 'bg-amber-500' :
                                'bg-red-500'
                              }`} />
                              {statuses[contact.id].status}
                            </span>
                          )}
                        </div>
                        
                        <div className="flex gap-1">
                          {contact.state && (
                            <span className="text-[10px] font-bold text-yellow-800 bg-yellow-50 px-2 py-0.5 rounded-md border border-yellow-100/50">
                              {contact.state}
                            </span>
                          )}
                          {contact.location && (
                            <span className="text-[10px] font-medium text-gray-500 bg-gray-50 px-2 py-0.5 rounded-md border border-gray-100">
                              {contact.location}
                            </span>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-start gap-4 mb-2">
                        <h3 className="font-bold text-gray-900 text-base leading-snug">{contact.name}</h3>
                        <button
                          onClick={() => toggleFavorite(contact.id)}
                          className="p-1.5 rounded-lg transition-all text-gray-400 hover:text-red-500 hover:bg-red-50 cursor-pointer flex-shrink-0"
                          title={isFav ? "Eliminar de favoritos" : "Guardar como favorito"}
                        >
                          <Heart 
                            className={`w-4 h-4 transition-all duration-300 ${
                              isFav 
                                ? 'fill-red-500 text-red-500 scale-110' 
                                : 'text-gray-400 hover:scale-105'
                            }`} 
                          />
                        </button>
                      </div>
                      
                      <p className="text-gray-600 text-xs leading-relaxed mb-4">{contact.description}</p>
                    </div>

                    <div className="space-y-2 mt-auto pt-4 border-t border-gray-50">
                      <div className="flex items-center justify-between text-xs bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                        <div className="flex items-center gap-2 font-mono text-gray-800">
                          <Phone className="w-3.5 h-3.5 text-gray-500" />
                          <span>{contact.phone}</span>
                        </div>
                        <div className="flex gap-1.5">
                          <button
                            onClick={() => copyToClipboard(contact.phone, contact.id)}
                            className="p-1.5 hover:bg-white hover:shadow-xs rounded-lg transition-all text-gray-500 hover:text-gray-800 border border-transparent hover:border-gray-200 cursor-pointer"
                            title="Copiar número"
                          >
                            {copiedId === contact.id ? (
                              <Check className="w-3.5 h-3.5 text-green-600 animate-pulse" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <a
                            href={`tel:${contact.phone.replace(/\s+/g, '')}`}
                            className="p-1.5 hover:bg-white hover:shadow-xs rounded-lg transition-all text-gray-500 hover:text-yellow-600 border border-transparent hover:border-gray-200 cursor-pointer"
                            title="Llamar"
                          >
                            <Phone className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      </div>

                      {contact.website && (
                        <a
                          href={contact.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center justify-between text-xs text-yellow-700 bg-yellow-50/50 hover:bg-yellow-50 px-3 py-2.5 rounded-xl border border-yellow-100/50 transition-all font-medium group"
                        >
                          <span>Visitar portal web oficial</span>
                          <ExternalLink className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                        </a>
                      )}
                    </div>

                    {/* Voz del Pueblo Status Updates */}
                    <NovedadesSection centerId={contact.id} />
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-white p-12 rounded-2xl text-center border border-gray-100 shadow-sm">
              <Heart className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500 text-sm font-medium">No se encontraron organizaciones que coincidan con los filtros de búsqueda.</p>
              {showOnlyFavorites && (
                <p className="text-gray-400 text-xs mt-1">
                  Prueba marcando algunos contactos del directorio con el ícono de <span className="text-red-500">❤️</span> para guardarlos en tus favoritos.
                </p>
              )}
            </div>
          )}

          {/* Dedicated Missing Persons Section */}
          <div className="border-t border-gray-200/80 pt-12 mt-12 space-y-6">
            <div className="bg-white p-6 rounded-2xl border-2 border-orange-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-gray-950 mb-2 flex items-center gap-2">
                  <Users className="w-5 h-5 text-orange-500" />
                  <span>Buscador y Registro de Personas Desaparecidas</span>
                </h2>
                <p className="text-gray-600 text-sm">
                  Espacio dedicado para que los familiares puedan reportar, buscar y coordinar la localización de seres queridos. Toda la información es mantenida en tiempo real por el pueblo.
                </p>
              </div>

              <button
                onClick={() => setIsMissingFormOpen(!isMissingFormOpen)}
                className="bg-orange-500 hover:bg-orange-600 text-white font-bold px-4 py-2.5 rounded-xl text-xs md:text-sm transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer self-start md:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>Registrar Desaparición</span>
              </button>
            </div>

            {/* Collapsible Report Form */}
            {isMissingFormOpen && (
              <div className="bg-white p-6 rounded-2xl border-2 border-orange-300 shadow-md">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-bold text-gray-950 text-base">Registrar Alerta de Persona Desaparecida</h3>
                  <button 
                    onClick={() => setIsMissingFormOpen(false)}
                    className="text-gray-400 hover:text-gray-600 text-sm font-bold cursor-pointer"
                  >
                    Cancelar
                  </button>
                </div>

                {missingFormError && (
                  <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                    <span>{missingFormError}</span>
                  </div>
                )}

                <form onSubmit={handleSubmitMissing} className="space-y-4">
                  {!auth.currentUser && (
                    <div className="p-3 bg-yellow-50 rounded-xl border border-yellow-100/50 mb-1">
                      <p className="text-xs text-yellow-800 font-semibold mb-1">
                        ℹ️ Publicación Anónima Activa: Escribe tu nombre o parentesco para que otros puedan contactarte.
                      </p>
                      <input
                        type="text"
                        placeholder="Ej. María Pérez (Hermana) o Juan Gómez (Vecino)"
                        value={missingReporterName}
                        onChange={(e) => setMissingReporterName(e.target.value)}
                        className="w-full bg-white border border-gray-200 rounded-xl px-4 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-orange-500 text-gray-950"
                      />
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                        Nombre Completo de la Persona
                      </label>
                      <input
                        type="text"
                        placeholder="Ej. Pedro José Rodríguez"
                        value={missingName}
                        onChange={(e) => setMissingName(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 text-gray-950"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                        Edad Aproximada (Opcional)
                      </label>
                      <input
                        type="number"
                        placeholder="Ej. 42"
                        value={missingAge}
                        onChange={(e) => setMissingAge(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 text-gray-950"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                        Último Lugar / Zona Visto (Ciudad o Estado)
                      </label>
                      <input
                        type="text"
                        placeholder="Ej. Sector El Viñedo, Valencia, Edo. Carabobo"
                        value={missingLastSeen}
                        onChange={(e) => setMissingLastSeen(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 text-gray-950"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                        Contacto Telefónico de la Familia
                      </label>
                      <input
                        type="text"
                        placeholder="Ej. +58 414-123-4567, o correo electrónico"
                        value={missingContact}
                        onChange={(e) => setMissingContact(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 text-gray-950"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                      Rasgos Físicos, Vestimenta y Detalles de la Desaparición
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Escribe detalles como altura aproximada, señas particulares (tatuajes, cicatrices), vestimenta que llevaba, o circunstancias conocidas."
                      value={missingDetails}
                      onChange={(e) => setMissingDetails(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 text-gray-950 resize-y"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmittingMissing}
                    className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-xl text-xs md:text-sm transition-all shadow-xs cursor-pointer disabled:opacity-50"
                  >
                    {isSubmittingMissing ? 'Publicando Reporte...' : 'Publicar Alerta de Desaparición'}
                  </button>
                </form>
              </div>
            )}

            {/* Live Search Bar for Missing Persons */}
            <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 flex flex-col md:flex-row gap-4 items-center">
              <div className="relative flex-1 w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Buscar familiar por nombre, ciudad, estado o rasgos..."
                  value={missingSearch}
                  onChange={(e) => setMissingSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white transition-all text-gray-950"
                />
              </div>
              <div className="text-xs text-gray-400 font-bold bg-gray-50 px-3.5 py-2 rounded-xl border border-gray-100 self-stretch md:self-auto flex items-center justify-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                <span>Alertas Activas: {filteredMissing.length}</span>
              </div>
            </div>

            {/* List of Missing Persons */}
            {isLoadingMissing ? (
              <div className="text-center py-12 bg-white rounded-2xl border border-gray-100 shadow-2xs">
                <div className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                <p className="text-xs text-gray-500 font-semibold">Cargando base de datos de personas desaparecidas...</p>
              </div>
            ) : filteredMissing.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredMissing.map(person => {
                  const isVerified = person.likesCount > 3 || (person.title && person.title.includes('VERIFICADO'));
                  return (
                    <div 
                      key={`missing-${person.id}`}
                      className="bg-white rounded-2xl p-5 border border-orange-100 shadow-2xs flex flex-col justify-between hover:border-orange-300 transition-all relative overflow-hidden"
                    >
                      {/* Flag accent */}
                      <div className="absolute top-0 left-0 w-1.5 h-full bg-orange-500" />

                      <div className="pl-2.5">
                        <div className="flex justify-between items-start gap-2 mb-2 flex-wrap">
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-red-50 text-red-600 border border-red-100 uppercase tracking-wider">
                            🚨 Alerta de Desaparición
                          </span>
                          
                          <div className="flex items-center gap-1 text-[10px] text-gray-400 font-mono">
                            <Clock className="w-3.5 h-3.5" />
                            <span>{new Date(person.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>

                        <h3 className="font-bold text-gray-950 text-base leading-tight mb-2">
                          {person.title.replace('Alerta de Desaparición: ', '')}
                        </h3>

                        <div className="flex items-center gap-1.5 text-xs text-gray-500 font-bold mb-4">
                          <MapPin className="w-3.5 h-3.5 text-orange-500" />
                          <span>Última vez visto: {person.location}</span>
                        </div>

                        <div className="bg-gray-50 p-3 rounded-xl border border-gray-100 mb-4">
                          <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Señas y circunstancias:</h4>
                          <p className="text-gray-700 text-xs leading-relaxed whitespace-pre-line font-medium">
                            {person.description.replace(/ÚLTIMA VEZ VISTO:.*?\n\nSEÑAS PARTICULARES & DETALLES:\n/, '')}
                          </p>
                        </div>

                        <div className="space-y-2 mb-4">
                          <div className="flex items-center justify-between text-xs bg-orange-50/50 p-2.5 rounded-xl border border-orange-100/40">
                            <div className="flex items-center gap-2 font-mono text-gray-800">
                              <Phone className="w-3.5 h-3.5 text-orange-500" />
                              <span>Familiar: {person.contactInfo}</span>
                            </div>
                            <button
                              onClick={() => copyToClipboard(person.contactInfo, person.id)}
                              className="p-1 hover:bg-white hover:shadow-2xs rounded-lg transition-all text-gray-500 hover:text-gray-800 border border-transparent cursor-pointer"
                              title="Copiar número"
                            >
                              {copiedId === person.id ? (
                                <Check className="w-3.5 h-3.5 text-green-600 animate-pulse" />
                              ) : (
                                <Copy className="w-3.5 h-3.5 text-gray-400" />
                              )}
                            </button>
                          </div>
                        </div>
                        
                        <div className="text-[10px] text-gray-400 font-semibold mb-4">
                          Reportado por: <span className="text-gray-600 font-bold">{person.authorName}</span>
                        </div>
                      </div>

                      {/* Avistamientos & Colaboración sub-section */}
                      <div className="border-t border-gray-100 pt-3 mt-2 pl-2.5">
                        <NovedadesSection centerId={person.id} />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="bg-white p-12 rounded-2xl text-center border border-gray-100 shadow-sm">
                <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 text-sm font-medium">No se encontraron reportes que coincidan con la búsqueda.</p>
                <p className="text-gray-400 text-xs mt-1">Si buscas a un familiar, puedes registrar una nueva alerta usando el botón naranja.</p>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
