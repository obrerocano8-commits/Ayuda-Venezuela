import React, { useState, useEffect } from 'react';
import { CommunityReport, NovedadStatus, NovedadItem } from '../types';
import { geocodeVenezuelaLocation } from '../lib/locationHelper';
import { 
  auth, 
  db, 
  googleProvider, 
  signInWithPopup, 
  signOut, 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  addDoc,
  deleteDoc,
  updateDoc,
  query, 
  orderBy, 
  where,
  onAuthStateChanged,
  User
} from '../firebase';
import { 
  LogIn, 
  LogOut, 
  Plus, 
  Trash2, 
  ThumbsUp, 
  MapPin, 
  Phone, 
  MessageSquare, 
  Tag, 
  Filter, 
  AlertCircle,
  Clock,
  Heart,
  Calendar,
  History,
  ShieldCheck,
  Shield
} from 'lucide-react';

export default function CommunityWallTab() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [reports, setReports] = useState<CommunityReport[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const getCategoryLabel = (cat: string) => {
    switch (cat) {
      case 'medicine': return '💊 Medicinas';
      case 'food': return '🍞 Alimentos';
      case 'health_center': return '🏥 Centros de Salud';
      case 'infrastructure': return '🛣️ Vías / Infraes.';
      case 'missing_person': return '🔍 Desaparecidos';
      case 'legal': return '⚖️ Asesoría Legal';
      case 'shelter': return '🏠 Refugio';
      default: return '📦 Otro';
    }
  };
  
  // Filters
  const [filterType, setFilterType] = useState<'all' | 'need' | 'offer'>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchLocation, setSearchLocation] = useState('');

  // Form State
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<'need' | 'offer'>('need');
  const [category, setCategory] = useState<'medicine' | 'food' | 'health_center' | 'legal' | 'shelter' | 'infrastructure' | 'missing_person' | 'other'>('medicine');
  const [location, setLocation] = useState('');
  const [contactInfo, setContactInfo] = useState('');
  const [guestAuthorName, setGuestAuthorName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  // Likes Tracking in LocalStorage to prevent double liking
  const [likedReports, setLikedReports] = useState<string[]>([]);

  // Collaborative Novedades State
  const [activeUpdateReportId, setActiveUpdateReportId] = useState<string | null>(null);
  const [statusInput, setStatusInput] = useState<NovedadStatus>('activo');
  const [statusDetails, setStatusDetails] = useState('');
  const [reporterAlias, setReporterAlias] = useState('');
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [novedadesMap, setNovedadesMap] = useState<Record<string, NovedadItem[]>>({});
  const [expandedHistories, setExpandedHistories] = useState<Record<string, boolean>>({});

  // Trusted Partner / Admin Verification State
  const TRUSTED_EMAILS = ['obrerocano8@gmail.com', 'admin@ayudavenezuela.org', 'trust@ayudavenezuela.org'];
  const [simulateTrustedPartner, setSimulateTrustedPartner] = useState(false);

  const isTrustedPartner = currentUser ? (
    TRUSTED_EMAILS.includes(currentUser.email || '') || simulateTrustedPartner
  ) : false;

  useEffect(() => {
    // Auth Listener
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        // Save user profile to Firestore (consistent with validation schema)
        try {
          const userRef = doc(db, 'users', user.uid);
          await setDoc(userRef, {
            userId: user.uid,
            displayName: user.displayName || 'Usuario de Apoyo',
            photoURL: user.photoURL || 'https://www.gravatar.com/avatar?d=mp',
            createdAt: new Date().toISOString()
          }, { merge: true });
        } catch (err) {
          console.error("Error updating user profile in Firestore:", err);
        }
      }
    });

    // Load liked reports from LocalStorage
    const savedLikes = localStorage.getItem('ayuda_vzla_likes');
    if (savedLikes) {
      try {
        setLikedReports(JSON.parse(savedLikes));
      } catch (e) {
        console.error(e);
      }
    }

    // Fetch reports
    fetchReports();

    return () => unsubscribeAuth();
  }, []);

  const fetchReports = async () => {
    setIsLoading(true);
    try {
      const reportsCol = collection(db, 'reports');
      // Fetch and sort locally to avoid mandatory index requirements during first runs
      const reportsSnapshot = await getDocs(reportsCol);
      const fetchedReports: CommunityReport[] = [];
      reportsSnapshot.forEach((document) => {
        fetchedReports.push({ id: document.id, ...document.data() } as CommunityReport);
      });
      // Sort by createdAt descending
      fetchedReports.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setReports(fetchedReports);
    } catch (err) {
      console.error("Error loading reports:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusLabelAndColor = (status?: NovedadStatus) => {
    switch (status) {
      case 'activo':
        return {
          label: 'Activo',
          badgeClass: 'bg-emerald-600 text-white',
          borderClass: 'border-emerald-200',
          dotClass: 'bg-emerald-500',
          textClass: 'text-emerald-700 font-semibold'
        };
      case 'sin_insumos':
        return {
          label: 'Sin Insumos',
          badgeClass: 'bg-red-600 text-white',
          borderClass: 'border-red-200',
          dotClass: 'bg-red-500',
          textClass: 'text-red-700 font-semibold'
        };
      case 'cerrado':
        return {
          label: 'Cerrado',
          badgeClass: 'bg-gray-600 text-white',
          borderClass: 'border-gray-200',
          dotClass: 'bg-gray-500',
          textClass: 'text-gray-700 font-semibold'
        };
      case 'recibiendo_donaciones':
        return {
          label: 'Recibiendo Donaciones',
          badgeClass: 'bg-amber-400 text-gray-950',
          borderClass: 'border-amber-200',
          dotClass: 'bg-amber-500',
          textClass: 'text-amber-700 font-semibold'
        };
      default:
        return {
          label: 'Sin Reporte de Estatus',
          badgeClass: 'bg-gray-100 text-gray-500',
          borderClass: 'border-gray-200',
          dotClass: 'bg-gray-300',
          textClass: 'text-gray-500'
        };
    }
  };

  const fetchNovedades = async (reportId: string) => {
    try {
      const novedadesCol = collection(db, 'reports', reportId, 'novedades');
      const snap = await getDocs(novedadesCol);
      const list: NovedadItem[] = [];
      snap.forEach(d => {
        list.push({ id: d.id, ...d.data() } as NovedadItem);
      });
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setNovedadesMap(prev => ({ ...prev, [reportId]: list }));
    } catch (err) {
      console.error("Error fetching novedades:", err);
    }
  };

  const toggleHistory = async (reportId: string) => {
    const isNowOpen = !expandedHistories[reportId];
    setExpandedHistories(prev => ({ ...prev, [reportId]: isNowOpen }));
    if (isNowOpen) {
      await fetchNovedades(reportId);
    }
  };

  const handleSubmitStatusUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeUpdateReportId) return;
    if (!statusDetails.trim()) {
      alert("Por favor, ingresa los detalles del reporte.");
      return;
    }

    setIsUpdatingStatus(true);
    try {
      const reportId = activeUpdateReportId;
      const finalAlias = reporterAlias.trim() || currentUser?.displayName || 'Colaborador Anónimo';

      // 1. Save to sub-collection 'novedades'
      const novedadesCol = collection(db, 'reports', reportId, 'novedades');
      const newNovedadRef = doc(novedadesCol);
      const novedadId = newNovedadRef.id;

      const novedadData: NovedadItem = {
        id: novedadId,
        status: statusInput,
        details: statusDetails,
        createdAt: new Date().toISOString(),
        reportedBy: finalAlias,
        userId: currentUser?.uid || 'guest'
      };

      await setDoc(newNovedadRef, novedadData);

      // 2. Update the main report document with the latest status
      const reportRef = doc(db, 'reports', reportId);
      await updateDoc(reportRef, {
        currentStatus: statusInput,
        currentStatusDetails: statusDetails,
        currentStatusAt: new Date().toISOString(),
        currentStatusBy: finalAlias
      });

      // Reset state & close form
      setStatusDetails('');
      setActiveUpdateReportId(null);
      
      // Refresh reports list
      await fetchReports();
      
      // Refresh this report's expanded history if open
      await fetchNovedades(reportId);
      
      alert("¡Estatus actualizado con éxito de manera colaborativa!");
    } catch (err: any) {
      console.error("Error updating status:", err);
      alert(`Error al actualizar el estatus: ${err.message || String(err)}`);
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const handleToggleVerification = async (reportId: string, currentVerifiedValue: boolean) => {
    if (!currentUser) {
      alert("Por favor, inicia sesión con Google para cambiar la verificación.");
      handleLogin();
      return;
    }
    if (!isTrustedPartner) {
      alert("No tienes permisos de Socio de Confianza o Admin para realizar esta acción.");
      return;
    }

    try {
      const reportRef = doc(db, 'reports', reportId);
      const newVerifiedValue = !currentVerifiedValue;
      
      await updateDoc(reportRef, {
        isVerified: newVerifiedValue,
        verifiedBy: newVerifiedValue ? (currentUser.displayName || currentUser.email || 'Socio de Confianza') : '',
        verifiedAt: newVerifiedValue ? new Date().toISOString() : ''
      });

      // Update the local state
      setReports(prev => prev.map(rep => {
        if (rep.id === reportId) {
          return {
            ...rep,
            isVerified: newVerifiedValue,
            verifiedBy: newVerifiedValue ? (currentUser.displayName || currentUser.email || 'Socio de Confianza') : '',
            verifiedAt: newVerifiedValue ? new Date().toISOString() : ''
          };
        }
        return rep;
      }));

      alert(newVerifiedValue 
        ? "¡Entrada marcada como VERIFICADA con éxito!" 
        : "Se ha removido la marca de verificación."
      );
    } catch (err: any) {
      console.error("Error toggling verification:", err);
      alert(`Error al actualizar la verificación: ${err.message || String(err)}`);
    }
  };

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.error("Error in login popup:", err);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error("Error in logout:", err);
    }
  };

  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    const authorNameValue = currentUser 
      ? (currentUser.displayName || 'Usuario de Apoyo') 
      : (guestAuthorName.trim() || 'Ciudadano Anónimo');

    const authorPhotoValue = currentUser 
      ? (currentUser.photoURL || 'https://www.gravatar.com/avatar?d=mp') 
      : 'https://www.gravatar.com/avatar?d=mp';

    const userIdValue = currentUser ? currentUser.uid : 'guest';

    if (title.length < 3 || title.length > 100) {
      setFormError('El título debe tener entre 3 y 100 caracteres.');
      return;
    }

    if (description.length < 10 || description.length > 2000) {
      setFormError('La descripción debe tener entre 10 y 2000 caracteres.');
      return;
    }

    if (location.length < 2 || location.length > 100) {
      setFormError('La ubicación debe tener entre 2 y 100 caracteres (especifica ciudad, sector, etc.).');
      return;
    }

    if (contactInfo.length < 3 || contactInfo.length > 200) {
      setFormError('La información de contacto debe tener entre 3 y 200 caracteres.');
      return;
    }

    setIsSubmitting(true);
    try {
      // Secure generate a document ID to comply with security rules
      const reportsCol = collection(db, 'reports');
      const newReportRef = doc(reportsCol); // generate random secure id
      const reportId = newReportRef.id;

      const { lat, lng } = geocodeVenezuelaLocation(location);

      const newReport: Omit<CommunityReport, 'id'> = {
        userId: userIdValue,
        authorName: authorNameValue,
        authorPhoto: authorPhotoValue,
        title,
        description,
        type,
        category,
        location,
        contactInfo,
        createdAt: new Date().toISOString(),
        likesCount: 0,
        lat,
        lng
      };

      await setDoc(newReportRef, { id: reportId, ...newReport });

      // Reset form
      setTitle('');
      setDescription('');
      setLocation('');
      setContactInfo('');
      setGuestAuthorName('');
      setIsFormOpen(false);
      
      // Refresh list
      await fetchReports();
    } catch (err: any) {
      console.error("Error creating report:", err);
      setFormError(`Error al crear el reporte en el servidor: ${err.message || String(err)}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleLike = async (reportId: string, currentLikes: number) => {
    const hasLiked = likedReports.includes(reportId);
    let newLikesCount = currentLikes;

    if (hasLiked) {
      newLikesCount = Math.max(0, currentLikes - 1);
    } else {
      newLikesCount = currentLikes + 1;
    }

    try {
      const reportRef = doc(db, 'reports', reportId);
      await updateDoc(reportRef, {
        likesCount: newLikesCount
      });

      // Update LocalStorage and state
      let updatedLikes = [...likedReports];
      if (hasLiked) {
        updatedLikes = updatedLikes.filter(id => id !== reportId);
      } else {
        updatedLikes.push(reportId);
      }
      setLikedReports(updatedLikes);
      localStorage.setItem('ayuda_vzla_likes', JSON.stringify(updatedLikes));

      // Refresh list to show accurate votes
      setReports(prev => prev.map(rep => rep.id === reportId ? { ...rep, likesCount: newLikesCount } : rep));
    } catch (err: any) {
      console.error("Error voting:", err);
      alert(`No se pudo registrar tu recomendación en el servidor: ${err.message}`);
    }
  };

  const handleDeleteReport = async (reportId: string) => {
    if (!window.confirm("¿Estás seguro de que quieres eliminar este reporte? Esta acción es irreversible.")) {
      return;
    }

    try {
      const reportRef = doc(db, 'reports', reportId);
      await deleteDoc(reportRef);
      setReports(prev => prev.filter(rep => rep.id !== reportId));
    } catch (err: any) {
      console.error("Error deleting report:", err);
      alert(`No se pudo eliminar el reporte del servidor: ${err.message}`);
    }
  };

  // Filtering
  const filteredReports = reports.filter(rep => {
    const matchesType = filterType === 'all' || rep.type === filterType;
    const matchesCategory = filterCategory === 'all' || rep.category === filterCategory;
    const matchesLocation = rep.location.toLowerCase().includes(searchLocation.toLowerCase());
    return matchesType && matchesCategory && matchesLocation;
  });

  const categories = [
    { value: 'all', label: 'Todas las Categorías' },
    { value: 'medicine', label: 'Medicinas' },
    { value: 'food', label: 'Alimentos' },
    { value: 'health_center', label: 'Centros de Salud' },
    { value: 'infrastructure', label: 'Estado de Vías' },
    { value: 'missing_person', label: 'Personas Desaparecidas' },
    { value: 'legal', label: 'Asesoría Legal' },
    { value: 'shelter', label: 'Refugio' },
    { value: 'other', label: 'Otro' }
  ];

  return (
    <div id="community-wall-tab" className="space-y-6">
      {/* Header and Auth status */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-950 mb-2">Muro Comunitario de Apoyo</h2>
          <p className="text-gray-600 text-sm">
            Un espacio de colaboración directa. Publica solicitudes de medicinas o alimentos, o bien ofrece ayuda a vecinos, organizaciones y comunidades en Venezuela.
          </p>
        </div>

        {/* Authentication controls */}
        <div className="flex-shrink-0">
          {currentUser ? (
            <div className="flex items-center gap-3 bg-gray-50 p-2.5 rounded-2xl border border-gray-100">
              <img 
                src={currentUser.photoURL || 'https://www.gravatar.com/avatar?d=mp'} 
                alt={currentUser.displayName || 'Avatar'} 
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-xl border border-gray-200"
              />
              <div className="text-left">
                <p className="text-xs font-bold text-gray-900 leading-tight">{currentUser.displayName}</p>
                <button 
                  onClick={handleLogout}
                  className="text-[10px] text-red-600 font-semibold hover:underline flex items-center gap-1 mt-0.5 cursor-pointer"
                >
                  <LogOut className="w-3 h-3" />
                  Cerrar Sesión
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={handleLogin}
              className="bg-gray-950 hover:bg-gray-800 text-white font-bold px-4 py-2.5 rounded-xl text-sm transition-all shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              Conectar con Google
            </button>
          )}
        </div>
      </div>

      {/* Trusted Partner Verification Status / Admin Bypass */}
      {currentUser && (
        <div className="bg-amber-50/40 border border-amber-200/60 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-xl ${isTrustedPartner ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-500'}`}>
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-gray-900 flex items-center gap-1.5">
                Rol de Verificación: 
                {isTrustedPartner ? (
                  <span className="text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-lg text-[10px] font-extrabold uppercase tracking-wide">Socio de Confianza Activo</span>
                ) : (
                  <span className="text-gray-500 bg-gray-200 px-2.5 py-0.5 rounded-lg text-[10px] font-extrabold uppercase tracking-wide">Usuario Estándar</span>
                )}
              </p>
              <p className="text-[11px] text-gray-500 mt-0.5">
                {isTrustedPartner 
                  ? "Tienes permisos para marcar anuncios como verificados y mitigar desinformación."
                  : "Los socios de confianza (Admins/Aliados) pueden auditar y verificar publicaciones oficiales."}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 bg-white px-3 py-2 rounded-xl border border-gray-200 self-stretch md:self-auto justify-between md:justify-start">
            <span className="text-xs font-bold text-gray-700">Simular Rol de Confianza (Pruebas)</span>
            <input 
              type="checkbox"
              checked={simulateTrustedPartner}
              onChange={(e) => setSimulateTrustedPartner(e.target.checked)}
              className="w-4 h-4 text-yellow-500 rounded border-gray-300 focus:ring-yellow-500 cursor-pointer"
            />
          </div>
        </div>
      )}

      {/* Control Bar: New report button + filters */}
      <div className="flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
        {/* Toggle between needs / offers / all */}
        <div className="flex bg-white p-1 rounded-xl border border-gray-100 shadow-sm self-start">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              filterType === 'all'
                ? 'bg-yellow-500 text-gray-950 shadow-xs'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Todos
          </button>
          <button
            onClick={() => setFilterType('need')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              filterType === 'need'
                ? 'bg-red-500 text-white shadow-xs'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Necesidades
          </button>
          <button
            onClick={() => setFilterType('offer')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              filterType === 'offer'
                ? 'bg-green-500 text-white shadow-xs'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Ofrecimientos
          </button>
        </div>

        {/* Action Button */}
        <button
          onClick={() => {
            setIsFormOpen(!isFormOpen);
          }}
          className="bg-yellow-500 hover:bg-yellow-600 text-gray-950 font-bold px-4 py-2.5 rounded-xl text-sm transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Publicar Anuncio</span>
        </button>
      </div>

      {/* Report Form (collapsible drawer) */}
      {isFormOpen && (
        <div className="bg-white p-6 rounded-2xl border-2 border-yellow-300 shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-gray-950 text-base">Crear Nuevo Anuncio de Apoyo</h3>
            <button 
              onClick={() => setIsFormOpen(false)}
              className="text-gray-400 hover:text-gray-600 text-sm font-bold cursor-pointer"
            >
              Cancelar
            </button>
          </div>

          {formError && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <form onSubmit={handleSubmitReport} className="space-y-4">
            {!currentUser && (
              <div className="p-4 bg-yellow-50 rounded-xl border border-yellow-100 mb-2">
                <p className="text-xs text-yellow-800 font-semibold mb-2">
                  ℹ️ Estás publicando como Ciudadano sin iniciar sesión. Puedes especificar un alias si lo deseas.
                </p>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                  Tu Nombre o Alias (Opcional)
                </label>
                <input
                  type="text"
                  placeholder="Ej. Juan de Mérida, o déjalo vacío para reportar de forma Anónima"
                  value={guestAuthorName}
                  onChange={(e) => setGuestAuthorName(e.target.value)}
                  className="w-full bg-white border border-gray-200 rounded-xl px-4 py-2.5 text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500 text-gray-900"
                />
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                  Tipo de Publicación
                </label>
                <div className="flex bg-gray-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setType('need')}
                    className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      type === 'need' ? 'bg-red-500 text-white' : 'text-gray-600'
                    }`}
                  >
                    Necesidad (Pido Ayuda)
                  </button>
                  <button
                    type="button"
                    onClick={() => setType('offer')}
                    className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      type === 'offer' ? 'bg-green-500 text-white' : 'text-gray-600'
                    }`}
                  >
                    Ofrecimiento (Ofrezco Ayuda)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                  Categoría
                </label>
                <select
                  value={category}
                  onChange={(e: any) => setCategory(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs md:text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-yellow-500 text-gray-800"
                >
                  <option value="medicine">💊 Medicinas</option>
                  <option value="food">🍞 Alimentos</option>
                  <option value="health_center">🏥 Centros de Salud</option>
                  <option value="infrastructure">🛣️ Estado de Vías / Infraestructura</option>
                  <option value="missing_person">🔍 Personas Desaparecidas</option>
                  <option value="legal">⚖️ Asesoría Legal</option>
                  <option value="shelter">🏠 Refugio / Albergue</option>
                  <option value="other">📦 Otro Apoyo</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                Título del Anuncio
              </label>
              <input
                type="text"
                placeholder="Ej. 'Se solicita insulina glargina urgente en Mérida' o 'Ofrezco donación de pañales pediátricos'"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500 text-gray-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                Descripción Detallada
              </label>
              <textarea
                rows={4}
                placeholder="Describe qué necesitas u ofreces, cantidades, para quién es, nivel de urgencia o disponibilidad. Sé específico."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500 text-gray-900"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                  Ubicación (Ciudad / Estado / Municipio)
                </label>
                <input
                  type="text"
                  placeholder="Ej. Caracas, Municipio Chacao o Barquisimeto, Estado Lara"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  required
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500 text-gray-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                  Información de Contacto
                </label>
                <input
                  type="text"
                  placeholder="Ej. Teléfono: 0414-XXXXXXX, Telegram o Correo electrónico"
                  value={contactInfo}
                  onChange={(e) => setContactInfo(e.target.value)}
                  required
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500 text-gray-900"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-yellow-500 hover:bg-yellow-600 disabled:bg-gray-200 disabled:text-gray-400 text-gray-950 font-bold py-3 rounded-xl text-sm transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              {isSubmitting ? 'Publicando en el servidor...' : 'Publicar en el Muro'}
            </button>
          </form>
        </div>
      )}

      {/* Filter and Search controls */}
      <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex flex-col md:flex-row gap-4">
        {/* Category dropdown */}
        <div className="w-full md:w-1/3">
          <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">
            Filtrar por Categoría
          </label>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none text-gray-700"
          >
            {categories.map(cat => (
              <option key={cat.value} value={cat.value}>
                {cat.label}
              </option>
            ))}
          </select>
        </div>

        {/* Location search input */}
        <div className="w-full md:w-2/3">
          <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">
            Filtrar por Ubicación en Venezuela
          </label>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar ciudad, ej. 'Mérida', 'Valencia', 'Caracas'..."
              value={searchLocation}
              onChange={(e) => setSearchLocation(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none text-gray-800"
            />
          </div>
        </div>
      </div>

      {/* Reports Listing Grid */}
      {isLoading ? (
        <div className="bg-white p-16 rounded-2xl border border-gray-100 text-center shadow-sm">
          <div className="inline-block w-8 h-8 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin mb-4" />
          <p className="text-gray-500 text-sm">Cargando anuncios del servidor de Firestore...</p>
        </div>
      ) : filteredReports.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {filteredReports.map((report) => {
            const hasLiked = likedReports.includes(report.id);
            const isAuthor = currentUser && currentUser.uid === report.userId;
            
            return (
              <div 
                key={report.id}
                className={`bg-white rounded-2xl p-5 border shadow-sm flex flex-col justify-between hover:shadow-md transition-all relative ${
                  report.type === 'need' ? 'border-red-100 hover:border-red-200' : 'border-green-100 hover:border-green-200'
                }`}
              >
                {/* Upper row: Creator and Date */}
                <div>
                  <div className="flex justify-between items-start gap-2 mb-3">
                    <div className="flex items-center gap-2">
                      <img 
                        src={report.authorPhoto || 'https://www.gravatar.com/avatar?d=mp'} 
                        alt={report.authorName} 
                        referrerPolicy="no-referrer"
                        className="w-8 h-8 rounded-lg border border-gray-100 object-cover"
                      />
                      <div className="text-left">
                        <h4 className="text-xs font-bold text-gray-950 truncate max-w-[150px]">
                          {report.authorName}
                        </h4>
                        <div className="flex items-center gap-1 text-[9px] text-gray-400 font-medium">
                          <Clock className="w-2.5 h-2.5" />
                          <span>{new Date(report.createdAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-1.5 items-center">
                      <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-bold ${
                        report.type === 'need' 
                          ? 'bg-red-50 text-red-700 border border-red-100' 
                          : 'bg-green-50 text-green-700 border border-green-100'
                      }`}>
                        {report.type === 'need' ? 'Necesidad' : 'Ofrecimiento'}
                      </span>
                      <span className="text-[9px] font-bold bg-gray-50 px-2 py-0.5 rounded-md border border-gray-100 text-gray-500 uppercase">
                        {getCategoryLabel(report.category)}
                      </span>
                    </div>
                  </div>

                  {/* Verification Badge */}
                  {report.isVerified && (
                    <div className="mb-3 p-2.5 bg-emerald-50/50 border border-emerald-200/60 rounded-xl flex items-center justify-between text-emerald-800 text-[11px] font-medium shadow-2xs">
                      <div className="flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-emerald-600 fill-emerald-100" />
                        <span>
                          <strong>Publicación Verificada:</strong> Validado por <span className="font-bold underline">{report.verifiedBy}</span>
                        </span>
                      </div>
                      {report.verifiedAt && (
                        <span className="text-[9px] text-emerald-600/80 font-normal">
                          {new Date(report.verifiedAt).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                  )}

                  {/* Title and details */}
                  <h3 className="font-bold text-gray-900 text-base mb-2 leading-snug">{report.title}</h3>
                  <p className="text-gray-600 text-xs leading-relaxed mb-3 whitespace-pre-line">
                    {report.description}
                  </p>

                  {/* Collaborative Status Section */}
                  {(() => {
                    const statusInfo = getStatusLabelAndColor(report.currentStatus);
                    return (
                      <div className={`mt-3 mb-4 p-3 rounded-xl border ${statusInfo.borderClass} bg-gray-50 flex flex-col gap-1.5`}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <span className={`w-2 h-2 rounded-full ${statusInfo.dotClass} ${report.currentStatus === 'activo' || report.currentStatus === 'recibiendo_donaciones' ? 'animate-pulse' : ''}`} />
                            <span className="text-[11px] font-bold text-gray-900">
                              Estatus: <span className={statusInfo.textClass}>{statusInfo.label}</span>
                            </span>
                          </div>
                          
                          {/* Actualizar Estatus Button */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (!currentUser) {
                                alert("Por favor, inicia sesión con Google para actualizar el estatus comunitariamente.");
                                handleLogin();
                                return;
                              }
                              setActiveUpdateReportId(report.id);
                              setStatusInput(report.currentStatus || 'activo');
                              setStatusDetails(report.currentStatusDetails || '');
                              setReporterAlias(currentUser.displayName || '');
                            }}
                            className="text-[10px] font-bold text-yellow-800 bg-yellow-100 hover:bg-yellow-200 px-2.5 py-1 rounded-lg transition-all cursor-pointer border border-yellow-200/50"
                          >
                            Actualizar Estatus
                          </button>
                        </div>
                        
                        {report.currentStatusDetails ? (
                          <p className="text-[11px] text-gray-600 leading-snug bg-white p-2 rounded-lg border border-gray-100/80">
                            "{report.currentStatusDetails}"
                          </p>
                        ) : (
                          <p className="text-[10px] text-gray-400 italic px-2">
                            Sin novedades detalladas. ¡Sé el primero en reportar la situación actual!
                          </p>
                        )}

                        {report.currentStatusAt && (
                          <div className="flex justify-between items-center text-[9px] text-gray-400 mt-0.5 px-2">
                            <span>Por: <strong className="text-gray-500 font-bold">{report.currentStatusBy || 'Colaborador'}</strong></span>
                            <span>{new Date(report.currentStatusAt).toLocaleString()}</span>
                          </div>
                        )}

                        {/* Historial Toggle button */}
                        <div className="border-t border-gray-200/40 pt-1.5 mt-0.5">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleHistory(report.id);
                            }}
                            className="w-full text-left text-[10px] text-gray-500 hover:text-gray-800 font-bold flex items-center justify-between cursor-pointer"
                          >
                            <span className="flex items-center gap-1">
                              <History className="w-3 h-3 text-gray-400" />
                              Ver Historial Comunitario ({novedadesMap[report.id]?.length !== undefined ? novedadesMap[report.id].length : 'Ver'})
                            </span>
                            <span>{expandedHistories[report.id] ? '▲ Ocultar' : '▼ Mostrar'}</span>
                          </button>
                          
                          {expandedHistories[report.id] && (
                            <div className="mt-2 space-y-2 max-h-40 overflow-y-auto pr-1">
                              {novedadesMap[report.id] === undefined ? (
                                <p className="text-[10px] text-gray-400 italic py-1 text-center animate-pulse">Cargando novedades...</p>
                              ) : novedadesMap[report.id].length === 0 ? (
                                <p className="text-[10px] text-gray-400 italic py-1 text-center">No hay registros previos en el historial.</p>
                              ) : (
                                novedadesMap[report.id].map((nov) => {
                                  const novStatus = getStatusLabelAndColor(nov.status);
                                  return (
                                    <div key={nov.id} className="bg-white p-2 rounded-lg border border-gray-100 text-[10px] text-gray-600 flex flex-col gap-1 shadow-2xs">
                                      <div className="flex items-center justify-between">
                                        <span className="flex items-center gap-1 font-bold">
                                          <span className={`w-1.5 h-1.5 rounded-full ${novStatus.dotClass}`} />
                                          <span className={novStatus.textClass}>{novStatus.label}</span>
                                        </span>
                                        <span className="text-gray-400 text-[8px]">{new Date(nov.createdAt).toLocaleString()}</span>
                                      </div>
                                      <p className="text-gray-700 bg-gray-50/50 p-1.5 rounded-sm">"{nov.details}"</p>
                                      <span className="text-gray-400 text-[8px] self-end">Por: <strong className="text-gray-600">{nov.reportedBy}</strong></span>
                                    </div>
                                  );
                                })
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })()}
                </div>

                {/* Lower metadata + buttons */}
                <div className="pt-4 border-t border-gray-50 space-y-3 mt-auto">
                  {/* Location & Contact */}
                  <div className="flex flex-col gap-1.5 text-[11px] text-gray-700">
                    <div className="flex items-center gap-1.5 font-medium">
                      <MapPin className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                      <span className="truncate">{report.location}</span>
                    </div>
                    <div className="flex items-center gap-1.5 font-mono text-gray-600 bg-gray-50 p-2 rounded-xl border border-gray-100">
                      <Phone className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                      <span className="truncate">{report.contactInfo}</span>
                    </div>
                  </div>

                  {/* Actions (Recommend / Delete) */}
                  <div className="flex items-center justify-between pt-1">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleToggleLike(report.id, report.likesCount)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                          hasLiked 
                            ? 'bg-yellow-500 border-yellow-500 text-gray-950 font-bold shadow-xs' 
                            : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                        }`}
                      >
                        <ThumbsUp className={`w-3.5 h-3.5 ${hasLiked ? 'fill-gray-950' : ''}`} />
                        <span>{report.likesCount} Recomendar</span>
                      </button>

                      {isTrustedPartner && (
                        <button
                          onClick={() => handleToggleVerification(report.id, !!report.isVerified)}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                            report.isVerified
                              ? 'bg-red-50 border-red-200 text-red-700 hover:bg-red-100'
                              : 'bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100'
                          }`}
                          title={report.isVerified ? "Desmarcar como Verificado" : "Marcar como Verificado"}
                        >
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>{report.isVerified ? 'Quitar Verificación' : 'Verificar'}</span>
                        </button>
                      )}
                    </div>

                    {isAuthor && (
                      <button
                        onClick={() => handleDeleteReport(report.id)}
                        className="text-red-500 hover:text-red-700 p-1.5 hover:bg-red-50 rounded-xl transition-all border border-transparent hover:border-red-100 cursor-pointer"
                        title="Eliminar Reporte"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white p-16 rounded-2xl text-center border border-gray-100 shadow-sm">
          <AlertCircle className="w-8 h-8 text-yellow-500 mx-auto mb-3" />
          <p className="text-gray-500 text-sm font-semibold">No hay publicaciones activas que coincidan con los filtros seleccionados.</p>
          <button
            onClick={() => {
              setFilterType('all');
              setFilterCategory('all');
              setSearchLocation('');
            }}
            className="text-yellow-600 hover:text-yellow-700 text-xs font-bold underline mt-2 cursor-pointer"
          >
            Limpiar filtros de búsqueda
          </button>
        </div>
      )}

      {/* Collaborative Status Update Modal */}
      {activeUpdateReportId && (
        <div className="fixed inset-0 bg-gray-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-gray-100 shadow-xl relative animate-in fade-in zoom-in-95 duration-150">
            <h3 className="font-bold text-gray-950 text-lg mb-1">¿Qué sucede ahora en este centro?</h3>
            <p className="text-gray-500 text-xs mb-4">
              Tu reporte actualizará el estatus público del centro de apoyo y se sumará al historial comunitario de novedades de manera colaborativa.
            </p>

            <form onSubmit={handleSubmitStatusUpdate} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                  Estatus Actualizado
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['activo', 'sin_insumos', 'cerrado', 'recibiendo_donaciones'] as const).map((statusVal) => {
                    const info = getStatusLabelAndColor(statusVal);
                    const isSelected = statusInput === statusVal;
                    return (
                      <button
                        key={statusVal}
                        type="button"
                        onClick={() => setStatusInput(statusVal)}
                        className={`p-2.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                          isSelected
                            ? `${info.badgeClass} border-transparent shadow-xs scale-102`
                            : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-white' : info.dotClass}`} />
                        <span>{info.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                  Detalles del Reporte (Corto)
                </label>
                <input
                  type="text"
                  maxLength={150}
                  placeholder="Ej. 'Abierto hasta las 4pm', 'Faltan jeringas', 'Recibiendo agua mineral'"
                  value={statusDetails}
                  onChange={(e) => setStatusDetails(e.target.value)}
                  required
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-yellow-500 text-gray-950"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                  Tu Alias / Nombre (Opcional)
                </label>
                <input
                  type="text"
                  maxLength={50}
                  placeholder="Ej. 'Dr. González', 'Vecino de Chacao', 'Anónimo'"
                  value={reporterAlias}
                  onChange={(e) => setReporterAlias(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-yellow-500 text-gray-950"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveUpdateReportId(null)}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold py-2.5 rounded-xl text-xs transition-all cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isUpdatingStatus}
                  className="flex-1 bg-yellow-500 hover:bg-yellow-600 disabled:bg-gray-200 text-gray-950 font-bold py-2.5 rounded-xl text-xs transition-all shadow-xs cursor-pointer"
                >
                  {isUpdatingStatus ? 'Guardando...' : 'Enviar Reporte'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
