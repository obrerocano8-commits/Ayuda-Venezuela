import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, MapPin, Send, ThumbsUp, X, Check, Eye } from 'lucide-react';

export default function TutorialModal() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // Check if user has already seen the tutorial
    const hasSeen = localStorage.getItem('ayuda_vzl_tutorial_shown');
    if (!hasSeen) {
      // Trigger modal entry with a slight delay for better UX
      const timer = setTimeout(() => {
        setIsOpen(true);
      }, 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    localStorage.setItem('ayuda_vzl_tutorial_shown', 'true');
    setIsOpen(false);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-100 flex items-center justify-center p-4">
          {/* Backdrop Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="absolute inset-0 bg-gray-950/65 backdrop-blur-xs cursor-pointer"
          />

          {/* Modal Content Box */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative bg-white rounded-3xl p-6 md:p-8 max-w-lg w-full shadow-2xl border border-gray-100/50 overflow-hidden font-sans z-10"
          >
            {/* Elegant corner decorative element */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/10 rounded-full blur-2xl -mr-12 -mt-12" />

            {/* Header */}
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-yellow-500 flex items-center justify-center shadow-xs">
                  <Sparkles className="w-5 h-5 text-gray-950" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-yellow-600 uppercase tracking-wider">
                    Nueva Función
                  </span>
                  <h3 className="text-xl font-extrabold text-gray-950 tracking-tight">
                    Primeros Pasos: Estatus en Vivo
                  </h3>
                </div>
              </div>
              <button
                onClick={handleClose}
                className="text-gray-400 hover:text-gray-600 p-1.5 hover:bg-gray-50 rounded-xl transition-all cursor-pointer"
                aria-label="Cerrar"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Body */}
            <div className="space-y-5 text-gray-700 text-sm mb-8">
              <p className="leading-relaxed">
                ¡Bienvenido a <strong>Ayuda Venezuela</strong>! Hemos implementado la sección <strong>"Voz del Pueblo"</strong>. Ahora puedes reportar y conocer el estatus en tiempo real de los centros de acopio y ayuda humanitaria:
              </p>

              {/* Step By Step Steps */}
              <div className="space-y-4">
                {/* Step 1 */}
                <div className="flex gap-4 items-start bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 font-extrabold text-xs flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-gray-900 text-sm mb-0.5">1. Encuentra un Centro</h4>
                    <p className="text-xs text-gray-500 leading-normal">
                      Navega en el <strong>Directorio de Apoyo</strong> o en el <strong>Mapa Interactivo</strong> para ver la lista de centros médicos, de acopio y refugios disponibles.
                    </p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="flex gap-4 items-start bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
                  <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 font-extrabold text-xs flex items-center justify-center flex-shrink-0">
                    <Eye className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-gray-900 text-sm mb-0.5">2. Consulta el Estado Actual</h4>
                    <p className="text-xs text-gray-500 leading-normal">
                      Visualiza si el centro está <strong className="text-emerald-600">Activo</strong>, <strong className="text-amber-600">Sin insumos</strong> o <strong className="text-red-600">Cerrado</strong> con base en los reportes más recientes del pueblo.
                    </p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="flex gap-4 items-start bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
                  <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 font-extrabold text-xs flex items-center justify-center flex-shrink-0">
                    <Send className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-gray-900 text-sm mb-0.5">3. Reporta o Confirma Estatus</h4>
                    <p className="text-xs text-gray-500 leading-normal">
                      ¿Estás en el sitio o tienes información fresca? Haz clic en <strong>"Actualizar Estatus"</strong> para reportar, o vota con un <strong className="text-blue-600">👍 de confirmación</strong> para validar reportes de otros.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Actions Button */}
            <button
              onClick={handleClose}
              className="w-full py-3.5 bg-yellow-500 hover:bg-yellow-600 text-gray-950 font-extrabold rounded-2xl text-xs md:text-sm flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md active:scale-98"
            >
              <Check className="w-4 h-4" />
              <span>¡Entendido, empezar a ayudar!</span>
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
