import React, { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import { SearchMessage, GroundingChunk } from '../types';
import { Search, MapPin, Sparkles, Send, Loader2, Globe, ExternalLink, HelpCircle } from 'lucide-react';

export default function AISearchTab() {
  const [query, setQuery] = useState('');
  const [searchType, setSearchType] = useState<'search' | 'maps'>('search');
  const [messages, setMessages] = useState<SearchMessage[]>([
    {
      id: 'init',
      sender: 'ai',
      text: '¡Hola! Soy tu asistente de **Ayuda Venezuela** con Inteligencia Artificial.\n\n¿Qué recurso estás buscando? Puedo buscar información en tiempo real usando **Google Search** o geolocalizar instituciones, hospitales y centros de acopio usando **Google Maps**.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [coords, setCoords] = useState<{ latitude: number; longitude: number } | null>(null);

  // Retrieve user location where relevant
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCoords({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
          console.log("Location successfully retrieved:", position.coords.latitude, position.coords.longitude);
        },
        (error) => {
          console.log("Geolocation permission denied or not available, using default Caracas coords.", error);
        }
      );
    }
  }, []);

  const handleQuerySubmit = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMessageId = `msg-${Date.now()}`;
    const userMsg: SearchMessage = {
      id: userMessageId,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setQuery('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/assist', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          prompt: textToSend,
          type: searchType,
          latLng: coords
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Error de red al consultar el servidor.");
      }

      const data = await response.json();

      const aiMsg: SearchMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        groundingChunks: data.groundingChunks
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (error: any) {
      console.error(error);
      const errorMsg: SearchMessage = {
        id: `err-${Date.now()}`,
        sender: 'ai',
        text: `⚠️ **Error:** ${error.message || "No se pudo obtener respuesta del servidor. Por favor, intenta más tarde."}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const suggestions = [
    { text: "Dónde conseguir insulina gratis en Caracas", type: "search" as const },
    { text: "Comedores comunitarios Cáritas activos", type: "search" as const },
    { text: "Hospitales pediátricos en Caracas", type: "maps" as const },
    { text: "Asesoría legal para derechos humanos en Maracaibo", type: "search" as const }
  ];

  return (
    <div id="ai-search-tab" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Search Console (Left side / Span 2) */}
      <div className="lg:col-span-2 flex flex-col h-[650px] bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-gray-100 bg-gray-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-yellow-100 rounded-xl text-yellow-800">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-gray-950 text-sm">Buscador Inteligente de Apoyo</h3>
              <p className="text-gray-500 text-[11px]">Consultas en tiempo real con datos de Google</p>
            </div>
          </div>

          {/* Toggle Type */}
          <div className="flex bg-gray-100 p-1 rounded-xl self-start sm:self-auto">
            <button
              onClick={() => setSearchType('search')}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                searchType === 'search'
                  ? 'bg-white text-gray-950 shadow-xs'
                  : 'text-gray-500 hover:text-gray-800'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Google Search</span>
            </button>
            <button
              onClick={() => setSearchType('maps')}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                searchType === 'maps'
                  ? 'bg-white text-gray-950 shadow-xs'
                  : 'text-gray-500 hover:text-gray-800'
              }`}
            >
              <MapPin className="w-3.5 h-3.5" />
              <span>Google Maps</span>
            </button>
          </div>
        </div>

        {/* Conversation Area */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-gray-50/30">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col max-w-[85%] ${
                msg.sender === 'user' ? 'ml-auto items-end' : 'mr-auto items-start'
              }`}
            >
              {/* Message Bubble */}
              <div
                className={`p-4 rounded-2xl border text-sm shadow-xs leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-yellow-500 border-yellow-600 text-gray-950 rounded-br-none'
                    : 'bg-white border-gray-100 text-gray-900 rounded-bl-none'
                }`}
              >
                {msg.sender === 'ai' ? (
                  <div className="markdown-body prose max-w-none text-xs md:text-sm prose-yellow">
                    <ReactMarkdown>{msg.text}</ReactMarkdown>
                  </div>
                ) : (
                  <p className="whitespace-pre-line font-medium">{msg.text}</p>
                )}
              </div>

              {/* Timestamp / Details */}
              <span className="text-[9px] text-gray-400 mt-1 px-1 font-mono">{msg.timestamp}</span>

              {/* Citations / Grounding Chunks (Only for AI message) */}
              {msg.sender === 'ai' && msg.groundingChunks && msg.groundingChunks.length > 0 && (
                <div className="mt-3 w-full bg-white rounded-xl p-3 border border-gray-100 shadow-2xs space-y-2">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1">
                    {searchType === 'maps' ? <MapPin className="w-3 h-3 text-red-500" /> : <Globe className="w-3 h-3 text-blue-500" />}
                    Fuentes y Enlaces Oficiales:
                  </span>
                  <div className="flex flex-wrap gap-2 max-h-[120px] overflow-y-auto pr-1">
                    {msg.groundingChunks.map((chunk, idx) => {
                      const isWeb = !!chunk.web;
                      const title = chunk.web?.title || chunk.maps?.title || `Enlace de Interés ${idx + 1}`;
                      const uri = chunk.web?.uri || chunk.maps?.uri;

                      if (!uri) return null;

                      return (
                        <a
                          key={idx}
                          href={uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1.5 text-[11px] bg-gray-50 border border-gray-100 hover:bg-yellow-50/50 hover:border-yellow-200 text-gray-700 hover:text-yellow-800 px-2.5 py-1.5 rounded-lg transition-all font-medium"
                        >
                          <span className="truncate max-w-[200px]">{title}</span>
                          <ExternalLink className="w-3 h-3 flex-shrink-0" />
                        </a>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-gray-500 text-xs bg-white border border-gray-100 shadow-2xs p-3 rounded-2xl w-fit">
              <Loader2 className="w-4 h-4 animate-spin text-yellow-600" />
              <span>
                {searchType === 'maps'
                  ? 'Buscando locaciones reales en Google Maps...'
                  : 'Consultando la web en tiempo real con Google Search...'}
              </span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-gray-100 bg-white">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleQuerySubmit(query);
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              placeholder={
                searchType === 'maps'
                  ? 'Escribe un lugar, ej. "Hospitales en Valencia" o "Cruz Roja Maracaibo"...'
                  : 'Busca alimentos, medicinas o servicios, ej. "Medicamentos gratis en Caracas"...'
              }
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              disabled={isLoading}
              className="flex-1 px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:bg-white transition-all text-gray-900 disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={isLoading || !query.trim()}
              className="bg-yellow-500 hover:bg-yellow-600 disabled:bg-gray-200 disabled:text-gray-400 text-gray-950 font-bold px-4 py-2.5 rounded-xl text-sm transition-all shadow-xs flex items-center justify-center gap-1 cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      {/* Guide / Suggestions (Right Side / Span 1) */}
      <div className="flex flex-col gap-4">
        {/* Info Card */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm space-y-4">
          <h4 className="font-bold text-gray-950 text-sm flex items-center gap-1.5">
            <HelpCircle className="w-4 h-4 text-yellow-600" />
            ¿Cómo funciona el buscador?
          </h4>
          
          <div className="space-y-3 text-xs text-gray-600 leading-relaxed">
            <div className="flex gap-2.5">
              <div className="w-1.5 h-1.5 rounded-full bg-yellow-500 mt-1.5 flex-shrink-0" />
              <p>
                <strong>Google Search Grounding:</strong> Consulta la web en tiempo real para encontrar reportes, páginas oficiales y noticias frescas sobre insumos médicos, donaciones y apoyo humanitario activo.
              </p>
            </div>
            
            <div className="flex gap-2.5">
              <div className="w-1.5 h-1.5 rounded-full bg-yellow-500 mt-1.5 flex-shrink-0" />
              <p>
                <strong>Google Maps Grounding:</strong> Geoposiciona clínicas, farmacias, comedores populares y centros asistenciales. Recupera direcciones y enlaces directos de mapas.
              </p>
            </div>

            {coords && (
              <div className="mt-4 p-2.5 bg-yellow-50 border border-yellow-100/60 rounded-xl text-yellow-800 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-yellow-600 flex-shrink-0" />
                <span>Tu geolocalización está habilitada. Las búsquedas de mapas se priorizarán cerca de ti.</span>
              </div>
            )}
          </div>
        </div>

        {/* Suggestion Card */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm">
          <h4 className="font-bold text-gray-950 text-sm mb-3">Sugerencias de Búsqueda</h4>
          <div className="flex flex-col gap-2.5">
            {suggestions.map((s, index) => (
              <button
                key={index}
                onClick={() => {
                  setSearchType(s.type);
                  handleQuerySubmit(s.text);
                }}
                className="w-full text-left p-3 bg-gray-50 hover:bg-yellow-50/50 border border-gray-100 hover:border-yellow-200 rounded-xl transition-all flex justify-between items-center group cursor-pointer"
              >
                <span className="text-xs text-gray-700 font-medium group-hover:text-yellow-900 truncate">
                  "{s.text}"
                </span>
                <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-white border border-gray-200 text-gray-500 uppercase flex-shrink-0">
                  {s.type === 'maps' ? 'Mapa' : 'Web'}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
