import React, { useState, useEffect } from 'react';
import { collection, doc, addDoc, updateDoc, onSnapshot, query, orderBy, db } from '../firebase';
import { increment } from 'firebase/firestore';
import { ThumbsUp, Calendar, AlertCircle, Sparkles, Send, CheckCircle2, XCircle } from 'lucide-react';

interface NovedadesSectionProps {
  centerId: string;
  onStatusChange?: (status: 'Activo' | 'Sin insumos' | 'Cerrado' | null) => void;
}

export interface NovedadItem {
  id: string;
  centerId: string;
  status: 'Activo' | 'Sin insumos' | 'Cerrado';
  note: string;
  reporterName: string;
  createdAt: string;
  votes: number;
}

export default function NovedadesSection({ centerId, onStatusChange }: NovedadesSectionProps) {
  const [novedades, setNovedades] = useState<NovedadItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  
  // Form State
  const [status, setStatus] = useState<'Activo' | 'Sin insumos' | 'Cerrado'>('Activo');
  const [note, setNote] = useState('');
  const [reporterName, setReporterName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Voted tracking (using localStorage to prevent double voting)
  const [votedIds, setVotedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(`voted_novedades_${centerId}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Listen to this center's updates in real time
  useEffect(() => {
    setLoading(true);
    const subcollectionRef = collection(db, 'centers', centerId, 'novedades');
    const q = query(subcollectionRef, orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: NovedadItem[] = [];
      snapshot.forEach((doc) => {
        items.push({
          id: doc.id,
          ...doc.data()
        } as NovedadItem);
      });
      
      setNovedades(items);
      setLoading(false);

      // Report active status back if callback is provided
      if (onStatusChange) {
        if (items.length > 0) {
          // Sort by votes desc, then date desc to find current highlighted status
          const sorted = [...items].sort((a, b) => {
            if (b.votes !== a.votes) return b.votes - a.votes;
            return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
          });
          onStatusChange(sorted[0].status);
        } else {
          onStatusChange(null);
        }
      }
    }, (error) => {
      console.error("Error listening to novedades:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [centerId, onStatusChange]);

  // Handle upvote
  const handleVote = async (novedadId: string) => {
    if (votedIds.includes(novedadId)) return;

    try {
      const docRef = doc(db, 'centers', centerId, 'novedades', novedadId);
      await updateDoc(docRef, {
        votes: increment(1)
      });

      const updatedVotes = [...votedIds, novedadId];
      setVotedIds(updatedVotes);
      localStorage.setItem(`voted_novedades_${centerId}`, JSON.stringify(updatedVotes));
    } catch (err) {
      console.error("Error voting:", err);
    }
  };

  // Submit new report
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!note.trim()) return;

    setIsSubmitting(true);
    try {
      const subcollectionRef = collection(db, 'centers', centerId, 'novedades');
      const payload = {
        centerId,
        status,
        note: note.trim(),
        reporterName: reporterName.trim() || 'Ciudadano',
        createdAt: new Date().toISOString(),
        votes: 0
      };

      await addDoc(subcollectionRef, payload);
      
      // Clean up form
      setNote('');
      setReporterName('');
      setShowForm(false);
      setSubmitSuccess(true);
      setTimeout(() => setSubmitSuccess(false), 3000);
    } catch (err) {
      console.error("Error adding status report:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Format date helper
  const formatTimeAgo = (dateStr: string) => {
    try {
      const diffMs = new Date().getTime() - new Date(dateStr).getTime();
      const diffMins = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffMins < 1) return 'Hace un momento';
      if (diffMins < 60) return `Hace ${diffMins} min`;
      if (diffHours < 24) return `Hace ${diffHours} h`;
      return `Hace ${diffDays} d`;
    } catch {
      return 'Recientemente';
    }
  };

  // Compute the current highlighted status (highest votes, then most recent)
  const sortedNovedades = [...novedades].sort((a, b) => {
    if (b.votes !== a.votes) return b.votes - a.votes;
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  const highlighted = sortedNovedades[0];

  return (
    <div className="mt-4 pt-4 border-t border-gray-100 font-sans">
      {/* Real-time Current Status Display */}
      <div className="mb-4">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
            Voz del Pueblo (Estatus Ciudadano)
          </span>
          <button
            onClick={() => setShowForm(!showForm)}
            className="text-[11px] font-bold text-yellow-600 hover:text-yellow-700 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <Sparkles className="w-3 h-3" />
            <span>{showForm ? 'Cancelar' : 'Actualizar Estatus'}</span>
          </button>
        </div>

        {/* Display Highlighted Status */}
        {highlighted ? (
          <div className="mt-2 p-3 bg-slate-50 border border-slate-100 rounded-xl relative overflow-hidden transition-all">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className={`inline-block w-2.5 h-2.5 rounded-full ${
                  highlighted.status === 'Activo' ? 'bg-emerald-500 animate-pulse' :
                  highlighted.status === 'Sin insumos' ? 'bg-amber-500' :
                  'bg-red-500'
                }`} />
                <strong className={`text-xs uppercase font-extrabold ${
                  highlighted.status === 'Activo' ? 'text-emerald-700' :
                  highlighted.status === 'Sin insumos' ? 'text-amber-700' :
                  'text-red-700'
                }`}>
                  {highlighted.status}
                </strong>
                {highlighted.votes >= 3 && (
                  <span className="bg-blue-100 text-blue-700 text-[9px] font-extrabold px-1.5 py-0.2 rounded-full border border-blue-200">
                    Verificado por Comunidad
                  </span>
                )}
              </div>
              <span className="text-[10px] text-gray-400 font-medium">
                {formatTimeAgo(highlighted.createdAt)}
              </span>
            </div>
            
            <p className="text-gray-700 text-xs mt-1.5 leading-relaxed font-medium">
              "{highlighted.note}"
            </p>
            
            <div className="flex justify-between items-center mt-2.5 pt-2 border-t border-gray-200/50 text-[10px] text-gray-400">
              <span>Reportado por: <strong className="text-gray-600">{highlighted.reporterName === 'Ciudadano' ? 'Ciudadano Anónimo' : highlighted.reporterName}</strong></span>
              <button
                onClick={() => handleVote(highlighted.id)}
                disabled={votedIds.includes(highlighted.id)}
                className={`flex items-center gap-1 px-2 py-1 rounded-lg transition-all ${
                  votedIds.includes(highlighted.id)
                    ? 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                    : 'bg-white hover:bg-gray-100 text-gray-500 hover:text-gray-800 border border-gray-200 cursor-pointer'
                }`}
              >
                <ThumbsUp className="w-2.5 h-2.5" />
                <span>{highlighted.votes} votos</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-2 p-3 bg-emerald-50/40 border border-emerald-100/60 rounded-xl text-center text-xs text-emerald-800">
            🟢 <strong>Activo</strong> (Estatus oficial predeterminado)
          </div>
        )}
      </div>

      {/* Success Animation Banner */}
      {submitSuccess && (
        <div className="mb-4 p-2.5 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-xl text-xs flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>¡Reporte enviado exitosamente en tiempo real! Gracias por tu honestidad.</span>
        </div>
      )}

      {/* Compact Quick-Submit Form (3 Clicks Flow) */}
      {showForm && (
        <form onSubmit={handleSubmit} className="p-4 bg-yellow-50/50 border border-yellow-100 rounded-xl space-y-3 mb-4 animate-fade-in">
          <h4 className="text-xs font-extrabold text-gray-800 flex items-center gap-1">
            <AlertCircle className="w-3.5 h-3.5 text-yellow-600" />
            <span>Reportar estado actual (Voz del Pueblo)</span>
          </h4>

          {/* Click 1: Select Status (tactile and large buttons) */}
          <div>
            <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">
              1. Selecciona el Estado del Centro:
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: 'Activo', color: 'border-emerald-200 bg-emerald-50 text-emerald-700 active-ring:ring-emerald-500', selectedColor: 'bg-emerald-600 text-white border-emerald-600 shadow-sm' },
                { value: 'Sin insumos', color: 'border-amber-200 bg-amber-50 text-amber-700 active-ring:ring-amber-500', selectedColor: 'bg-amber-500 text-white border-amber-500 shadow-sm' },
                { value: 'Cerrado', color: 'border-red-200 bg-red-50 text-red-700 active-ring:ring-red-500', selectedColor: 'bg-red-600 text-white border-red-600 shadow-sm' }
              ].map(opt => {
                const isSelected = status === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setStatus(opt.value as any)}
                    className={`py-2 px-1 rounded-xl text-xs font-extrabold border transition-all cursor-pointer text-center ${
                      isSelected ? opt.selectedColor : `${opt.color} hover:brightness-95`
                    }`}
                  >
                    {opt.value}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Click 2: Add short observation */}
          <div>
            <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">
              2. Nota rápida o faltantes:
            </label>
            <textarea
              placeholder="Ej: Solo atienden emergencias médicas / No quedan alimentos..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={2}
              required
              maxLength={200}
              className="w-full p-2 text-xs bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-yellow-500 text-gray-900 font-medium"
            />
          </div>

          {/* Optional: Citizen Name */}
          <div>
            <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">
              Nombre o Apodo (Opcional):
            </label>
            <input
              type="text"
              placeholder="Dejar vacío para anónimo (Ciudadano)"
              value={reporterName}
              onChange={(e) => setReporterName(e.target.value)}
              maxLength={30}
              className="w-full p-2 text-xs bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-yellow-500 text-gray-900 font-medium"
            />
          </div>

          {/* Click 3: Send */}
          <button
            type="submit"
            disabled={isSubmitting || !note.trim()}
            className="w-full py-2 bg-yellow-500 hover:bg-yellow-600 text-gray-950 font-extrabold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 transition-colors shadow-xs"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{isSubmitting ? 'Publicando...' : 'Enviar Reporte en Vivo'}</span>
          </button>
        </form>
      )}

      {/* History and community feedback updates */}
      {novedades.length > 1 && (
        <div className="mt-4">
          <button
            type="button"
            className="text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-2 hover:text-gray-600 transition-colors"
          >
            Historial de Reportes ({novedades.length})
          </button>
          <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
            {novedades.slice(1).map((item) => (
              <div key={item.id} className="p-2 border border-gray-100 rounded-lg bg-gray-50/50 flex flex-col gap-1 text-[11px]">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className={`inline-block w-1.5 h-1.5 rounded-full ${
                      item.status === 'Activo' ? 'bg-emerald-500' :
                      item.status === 'Sin insumos' ? 'bg-amber-500' :
                      'bg-red-500'
                    }`} />
                    <span className="font-bold text-gray-700">{item.status}</span>
                  </div>
                  <span className="text-gray-400 text-[9px]">{formatTimeAgo(item.createdAt)}</span>
                </div>
                <p className="text-gray-600 font-medium">"{item.note}"</p>
                <div className="flex justify-between items-center text-[9px] text-gray-400 mt-1">
                  <span>Por: {item.reporterName}</span>
                  <button
                    onClick={() => handleVote(item.id)}
                    disabled={votedIds.includes(item.id)}
                    className={`flex items-center gap-0.5 px-1.5 py-0.5 rounded transition-all ${
                      votedIds.includes(item.id)
                        ? 'text-emerald-600 bg-emerald-50'
                        : 'text-gray-500 hover:text-gray-800 hover:bg-gray-100 cursor-pointer'
                    }`}
                  >
                    👍 <span>{item.votes}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
