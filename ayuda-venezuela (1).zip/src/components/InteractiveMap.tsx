import React, { useEffect, useRef, useState } from 'react';
import { EmergencyContact } from '../types';
import { MapPin, Navigation, Crosshair, Phone, ExternalLink, Search, Sparkles, AlertCircle, Heart } from 'lucide-react';
import { CenterStatus } from '../hooks/useRealtimeStatuses';
import NovedadesSection from './NovedadesSection';

interface InteractiveMapProps {
  contacts: EmergencyContact[];
  realtimeStatuses?: Record<string, CenterStatus>;
}

export default function InteractiveMap({ contacts, realtimeStatuses }: InteractiveMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);
  const userMarkerRef = useRef<any>(null);
  const userCircleRef = useRef<any>(null);

  const [leafletLoaded, setLeafletLoaded] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locating, setLocating] = useState(false);
  const [selectedContact, setSelectedContact] = useState<EmergencyContact | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  
  // Distances stored for nearest contacts
  const [distances, setDistances] = useState<{ [id: string]: number }>({});

  // 1. Dynamic loader for Leaflet assets (Zero-API Key requirement)
  useEffect(() => {
    let script: HTMLScriptElement | null = null;
    let link: HTMLLinkElement | null = null;

    const checkAndLoad = () => {
      if ((window as any).L) {
        setLeafletLoaded(true);
        return;
      }

      // Add stylesheet
      if (!document.getElementById('leaflet-css')) {
        link = document.createElement('link');
        link.id = 'leaflet-css';
        link.rel = 'stylesheet';
        link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
        document.head.appendChild(link);
      }

      // Add script
      if (!document.getElementById('leaflet-js')) {
        script = document.createElement('script');
        script.id = 'leaflet-js';
        script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
        script.async = true;
        script.onload = () => {
          setLeafletLoaded(true);
        };
        script.onerror = () => {
          setLoadError(true);
        };
        document.body.appendChild(script);
      } else {
        // Script added but maybe not loaded yet
        const interval = setInterval(() => {
          if ((window as any).L) {
            setLeafletLoaded(true);
            clearInterval(interval);
          }
        }, 100);
        return () => clearInterval(interval);
      }
    };

    checkAndLoad();

    return () => {
      // Keep Leaflet globally, but make sure to clean up map instances
    };
  }, []);

  // 2. Map Initialization
  useEffect(() => {
    if (!leafletLoaded || !containerRef.current) return;
    const L = (window as any).L;
    if (!L) return;

    // Destroy existing map if it exists
    if (mapRef.current) {
      mapRef.current.remove();
      mapRef.current = null;
    }

    // Default center in Venezuela (approx. Caracas/central valley zoom)
    const map = L.map(containerRef.current, {
      center: [10.2, -67.5],
      zoom: 7,
      zoomControl: false // Custom styled zoom controls can be used, or default below
    });

    L.control.zoom({ position: 'topright' }).addTo(map);

    // Beautiful light-themed tiles matching our minimalist aesthetic
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
      subdomains: 'abcd',
      maxZoom: 20
    }).addTo(map);

    mapRef.current = map;

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [leafletLoaded]);

  // 3. Clear and Render Markers
  useEffect(() => {
    const map = mapRef.current;
    const L = (window as any).L;
    if (!map || !L) return;

    // Clear previous markers
    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];

    // Filter contacts to show
    const mapContacts = contacts.filter(contact => {
      if (!contact.lat || !contact.lng) return false;
      const matchesSearch = 
        contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        contact.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (contact.location && contact.location.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesCategory = categoryFilter === 'All' || contact.category === categoryFilter;
      return matchesSearch && matchesCategory;
    });

    // Custom marker style generator based on category and status
    const getMarkerIcon = (contactId: string, category: string) => {
      let color = '#f59e0b'; // amber
      if (category === 'Salud') color = '#ef4444'; // red
      if (category === 'Alimentos') color = '#22c55e'; // green
      if (category === 'Ayuda Legal') color = '#3b82f6'; // blue

      const rStatus = realtimeStatuses?.[contactId]?.status;
      let statusDot = '';
      if (rStatus === 'Activo') {
        statusDot = `<span class="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full shadow-sm animate-pulse"></span>`;
      } else if (rStatus === 'Sin insumos') {
        statusDot = `<span class="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-500 border-2 border-white rounded-full shadow-sm"></span>`;
      } else if (rStatus === 'Cerrado') {
        statusDot = `<span class="absolute -top-1 -right-1 w-3.5 h-3.5 bg-red-600 border-2 border-white rounded-full shadow-sm"></span>`;
      }

      return L.divIcon({
        html: `
          <div class="relative flex items-center justify-center">
            <span class="absolute inline-flex h-6 w-6 rounded-full opacity-35 animate-ping" style="background-color: ${color}"></span>
            <div class="w-8 h-8 rounded-full border-2 border-white shadow-md flex items-center justify-center transition-all duration-300 hover:scale-110" style="background-color: ${color}">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/>
                <circle cx="12" cy="10" r="3"/>
              </svg>
            </div>
            ${statusDot}
          </div>
        `,
        className: 'custom-leaflet-icon',
        iconSize: [32, 32],
        iconAnchor: [16, 16],
        popupAnchor: [0, -16]
      });
    };

    // Plot markers
    mapContacts.forEach(contact => {
      if (!contact.lat || !contact.lng) return;

      const marker = L.marker([contact.lat, contact.lng], {
        icon: getMarkerIcon(contact.id, contact.category)
      }).addTo(map);

      // Realtime Status HTML for Popup
      const rStatus = realtimeStatuses?.[contact.id];
      const rStatusHtml = rStatus ? `
        <div class="mt-2 p-1.5 rounded-lg border text-[10px] leading-tight ${
          rStatus.status === 'Activo' ? 'bg-emerald-50 text-emerald-800 border-emerald-100' :
          rStatus.status === 'Sin insumos' ? 'bg-amber-50 text-amber-800 border-amber-100' :
          'bg-red-50 text-red-800 border-red-100'
        }">
          <strong>Estatus:</strong> ${rStatus.status}<br/>
          <span class="text-gray-600 italic">"${rStatus.note}"</span>
        </div>
      ` : '';

      // Popup Content matching Tailwind styles
      const popupContent = `
        <div class="p-2 font-sans max-w-[240px]">
          <span class="inline-block px-2 py-0.5 rounded-full text-[9px] font-bold uppercase mb-1.5 ${
            contact.category === 'Salud' ? 'bg-red-100 text-red-800' :
            contact.category === 'Alimentos' ? 'bg-green-100 text-green-800' :
            contact.category === 'Ayuda Legal' ? 'bg-blue-100 text-blue-800' :
            'bg-amber-100 text-amber-800'
          }">${contact.category}</span>
          <h4 class="font-extrabold text-sm text-gray-900 leading-tight mb-1">${contact.name}</h4>
          <p class="text-gray-600 text-[11px] leading-snug mb-1">${contact.description}</p>
          ${rStatusHtml}
          <div class="text-[11px] font-bold text-gray-800 flex items-center gap-1 mt-2">
            📞 <span>${contact.phone}</span>
          </div>
        </div>
      `;

      marker.bindPopup(popupContent);

      marker.on('click', () => {
        setSelectedContact(contact);
        map.setView([contact.lat, contact.lng], 13);
      });

      markersRef.current.push(marker);
    });

  }, [contacts, leafletLoaded, searchQuery, categoryFilter]);

  // 4. Calculate Distance from User location using Haversine formula
  const calculateHaversineDistances = (lat: number, lng: number) => {
    const R = 6371; // Earth radius in km
    const newDistances: { [id: string]: number } = {};

    contacts.forEach(contact => {
      if (!contact.lat || !contact.lng) return;
      const dLat = (contact.lat - lat) * Math.PI / 180;
      const dLng = (contact.lng - lng) * Math.PI / 180;
      const a = 
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat * Math.PI / 180) * Math.cos(contact.lat * Math.PI / 180) * 
        Math.sin(dLng / 2) * Math.sin(dLng / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      const distance = R * c;
      newDistances[contact.id] = distance;
    });

    setDistances(newDistances);
  };

  // 5. User Geolocation Handler
  const handleDetectLocation = () => {
    const L = (window as any).L;
    const map = mapRef.current;
    if (!L || !map) return;

    setLocating(true);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setUserLocation({ lat: latitude, lng: longitude });
        setLocating(false);

        // Pan map to user
        map.setView([latitude, longitude], 11);

        // Remove old user markers
        if (userMarkerRef.current) userMarkerRef.current.remove();
        if (userCircleRef.current) userCircleRef.current.remove();

        // Pulsing dot for user location
        const userIcon = L.divIcon({
          html: `
            <div class="relative flex items-center justify-center">
              <span class="absolute inline-flex h-5 w-5 rounded-full bg-blue-500 opacity-65 animate-ping"></span>
              <div class="w-4 h-4 rounded-full border-2 border-white shadow-lg bg-blue-600"></div>
            </div>
          `,
          className: 'user-location-marker',
          iconSize: [20, 20],
          iconAnchor: [10, 10]
        });

        userMarkerRef.current = L.marker([latitude, longitude], { icon: userIcon }).addTo(map);

        // Transparent perimeter accuracy circle
        userCircleRef.current = L.circle([latitude, longitude], {
          radius: 12000, // 12km radius highlight
          color: '#3b82f6',
          fillColor: '#3b82f6',
          fillOpacity: 0.08,
          weight: 1.5,
          dashArray: '4, 4'
        }).addTo(map);

        // Update distances
        calculateHaversineDistances(latitude, longitude);
      },
      (error) => {
        console.error("Geolocation error:", error);
        setLocating(false);
        
        // Caracas default simulated user location for offline/fallback demonstration
        const mockLat = 10.4806;
        const mockLng = -66.9036;
        setUserLocation({ lat: mockLat, lng: mockLng });
        map.setView([mockLat, mockLng], 11);

        if (userMarkerRef.current) userMarkerRef.current.remove();
        if (userCircleRef.current) userCircleRef.current.remove();

        const userIcon = L.divIcon({
          html: `
            <div class="relative flex items-center justify-center">
              <span class="absolute inline-flex h-5 w-5 rounded-full bg-yellow-500 opacity-65 animate-ping"></span>
              <div class="w-4 h-4 rounded-full border-2 border-white shadow-lg bg-yellow-600"></div>
            </div>
          `,
          className: 'user-location-marker',
          iconSize: [20, 20],
          iconAnchor: [10, 10]
        });

        userMarkerRef.current = L.marker([mockLat, mockLng], { icon: userIcon }).addTo(map);
        userCircleRef.current = L.circle([mockLat, mockLng], {
          radius: 15000,
          color: '#eab308',
          fillColor: '#eab308',
          fillOpacity: 0.06,
          weight: 1.5,
          dashArray: '4, 4'
        }).addTo(map);

        calculateHaversineDistances(mockLat, mockLng);
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const handleFlyTo = (contact: EmergencyContact) => {
    const map = mapRef.current;
    const L = (window as any).L;
    if (!map || !L || !contact.lat || !contact.lng) return;

    setSelectedContact(contact);
    map.setView([contact.lat, contact.lng], 14);

    // Open popup for this marker
    const marker = markersRef.current.find(m => {
      const latlng = m.getLatLng();
      return Math.abs(latlng.lat - (contact.lat || 0)) < 0.0001 && 
             Math.abs(latlng.lng - (contact.lng || 0)) < 0.0001;
    });

    if (marker) {
      marker.openPopup();
    }
  };

  // Filter contacts list for sidebar display
  const sidebarContacts = contacts
    .filter(c => {
      if (!c.lat || !c.lng) return false;
      const matchesSearch = 
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = categoryFilter === 'All' || c.category === categoryFilter;
      return matchesSearch && matchesCategory;
    })
    .map(c => ({
      ...c,
      distance: distances[c.id]
    }))
    .sort((a, b) => {
      if (a.distance !== undefined && b.distance !== undefined) {
        return a.distance - b.distance;
      }
      return 0;
    });

  return (
    <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden flex flex-col lg:flex-row h-[620px]">
      
      {/* Interactive Map Visual Stage */}
      <div className="flex-1 relative h-[300px] lg:h-full">
        {!leafletLoaded && !loadError && (
          <div className="absolute inset-0 bg-slate-50 flex flex-col items-center justify-center gap-3 z-10">
            <div className="w-10 h-10 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs font-bold text-gray-500 font-sans">Cargando Mapa Satelital Offline...</p>
          </div>
        )}

        {loadError && (
          <div className="absolute inset-0 bg-red-50 flex flex-col items-center justify-center gap-3 z-10 p-6 text-center">
            <AlertCircle className="w-8 h-8 text-red-500" />
            <h4 className="font-extrabold text-gray-950 text-sm">Error de Conexión</h4>
            <p className="text-gray-500 text-xs max-w-sm">No se pudo cargar el motor del mapa interactivo. Por favor, asegúrate de estar conectado a internet o navega el directorio en formato lista.</p>
          </div>
        )}

        {/* Map div container */}
        <div 
          ref={containerRef} 
          id="leaflet-map-element" 
          className="w-full h-full"
          style={{ minHeight: '100%' }}
        />

        {/* Floating Quick Navigation & Tools overlay */}
        <div className="absolute top-4 left-4 z-[999] flex flex-col gap-2">
          <button
            onClick={handleDetectLocation}
            disabled={locating}
            className="bg-white hover:bg-gray-50 text-gray-900 border border-gray-200 shadow-lg p-2.5 rounded-2xl flex items-center gap-2 text-xs font-bold transition-all hover:scale-103 cursor-pointer select-none active:scale-97"
          >
            <Navigation className={`w-4 h-4 text-yellow-500 ${locating ? 'animate-spin' : ''}`} />
            <span>{locating ? 'Ubicando...' : 'Centros Cercanos a Mí'}</span>
          </button>
        </div>

        {/* Floating Map Info HUD */}
        {selectedContact && (
          <div className="absolute bottom-4 left-4 right-4 lg:right-auto lg:max-w-xs bg-white/95 backdrop-blur-md p-4 rounded-2xl border border-gray-100 shadow-xl z-[999] animate-fade-in max-h-[380px] overflow-y-auto">
            <div className="flex justify-between items-start gap-2 mb-1">
              <span className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase ${
                selectedContact.category === 'Salud' ? 'bg-red-100 text-red-800' :
                selectedContact.category === 'Alimentos' ? 'bg-green-100 text-green-800' :
                selectedContact.category === 'Ayuda Legal' ? 'bg-blue-100 text-blue-800' :
                'bg-amber-100 text-amber-800'
              }`}>{selectedContact.category}</span>
              <button 
                onClick={() => setSelectedContact(null)}
                className="text-gray-400 hover:text-gray-700 text-xs font-bold px-1.5 py-0.5 bg-gray-100 rounded-lg cursor-pointer"
              >
                ✕
              </button>
            </div>
            <h4 className="font-extrabold text-sm text-gray-950 leading-tight mb-1">{selectedContact.name}</h4>
            <p className="text-gray-500 text-[11px] leading-snug mb-3">{selectedContact.description}</p>
            <div className="flex gap-2 mb-3">
              <a
                href={`tel:${selectedContact.phone.replace(/\s+/g, '')}`}
                className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-gray-950 font-extrabold py-1.5 rounded-xl text-[11px] flex items-center justify-center gap-1 cursor-pointer transition-colors shadow-2xs"
              >
                <Phone className="w-3 h-3" />
                <span>Llamar</span>
              </a>
              {selectedContact.website && (
                <a
                  href={selectedContact.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-gray-100 hover:bg-gray-200 text-gray-700 p-1.5 rounded-xl flex items-center justify-center cursor-pointer transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>

            {/* Realtime Citizen Status updates on Map detail HUD */}
            <NovedadesSection centerId={selectedContact.id} />
          </div>
        )}
      </div>

      {/* Sidebar Control Center & Locations catalog */}
      <div className="w-full lg:w-[340px] border-t lg:border-t-0 lg:border-l border-gray-100 flex flex-col h-[320px] lg:h-full bg-gray-50/50">
        <div className="p-4 border-b border-gray-100 bg-white">
          <h3 className="font-extrabold text-gray-950 text-sm mb-1.5 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-yellow-500" />
            <span>Localizador Inteligente</span>
          </h3>
          <p className="text-gray-500 text-[11px] leading-snug mb-3">
            Compara distancias y encuentra puestos de respuesta o comedores activos ordenados de menor a mayor distancia.
          </p>

          <div className="space-y-2">
            {/* Direct Keyword Finder */}
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
              <input
                type="text"
                placeholder="Filtrar por nombre o palabra..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:bg-white text-gray-950 font-medium"
              />
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-1.5">
              {['All', 'Salud', 'Alimentos', 'Ayuda Legal'].map(cat => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${
                    categoryFilter === cat
                      ? 'bg-yellow-500 border-yellow-500 text-gray-950'
                      : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  {cat === 'All' ? 'Todos' : cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Scrollable list of matched centers with distances */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
          {userLocation && (
            <div className="p-2.5 bg-emerald-50/40 border border-emerald-100 rounded-xl flex items-start gap-2 text-emerald-800 text-[11px] leading-relaxed mb-1">
              <MapPin className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0 mt-0.5" />
              <div>
                <strong>Ubicación detectada:</strong> Calculando distancias geodésicas en tiempo real a los centros de acopio.
              </div>
            </div>
          )}

          {sidebarContacts.length > 0 ? (
            sidebarContacts.map(contact => {
              const isSelected = selectedContact?.id === contact.id;
              return (
                <div
                  key={`map-item-${contact.id}`}
                  onClick={() => handleFlyTo(contact)}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer text-left group ${
                    isSelected
                      ? 'bg-yellow-500/10 border-yellow-400/80 shadow-xs'
                      : 'bg-white border-gray-100 hover:border-gray-300'
                  }`}
                >
                  <div className="flex justify-between items-start gap-1 mb-1 flex-wrap">
                    <div className="flex items-center gap-1">
                      <span className={`px-2 py-0.2 rounded text-[8px] font-extrabold uppercase tracking-wider ${
                        contact.category === 'Salud' ? 'bg-red-50 text-red-700' :
                        contact.category === 'Alimentos' ? 'bg-green-50 text-green-700' :
                        contact.category === 'Ayuda Legal' ? 'bg-blue-50 text-blue-700' :
                        'bg-amber-50 text-amber-700'
                      }`}>{contact.category}</span>
                      
                      {realtimeStatuses?.[contact.id] && (
                        <span className={`px-1.5 py-0.2 rounded text-[8px] font-extrabold flex items-center gap-0.5 border ${
                          realtimeStatuses[contact.id].status === 'Activo' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                          realtimeStatuses[contact.id].status === 'Sin insumos' ? 'bg-amber-50 text-amber-700 border-amber-100' :
                          'bg-red-50 text-red-700 border-red-100'
                        }`}>
                          <span className={`inline-block w-1 h-1 rounded-full ${
                            realtimeStatuses[contact.id].status === 'Activo' ? 'bg-emerald-500 animate-pulse' :
                            realtimeStatuses[contact.id].status === 'Sin insumos' ? 'bg-amber-500' :
                            'bg-red-500'
                          }`} />
                          {realtimeStatuses[contact.id].status}
                        </span>
                      )}
                    </div>
                    
                    {/* Render exact distance computed by Haversine formula */}
                    {contact.distance !== undefined ? (
                      <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded border border-blue-100 flex items-center gap-0.5 animate-pulse">
                        📍 {contact.distance.toFixed(1)} km
                      </span>
                    ) : (
                      <span className="text-[9px] text-gray-400 font-mono">
                        {contact.state}
                      </span>
                    )}
                  </div>

                  <h4 className="font-extrabold text-xs text-gray-900 group-hover:text-yellow-600 transition-colors leading-tight">{contact.name}</h4>
                  <p className="text-gray-500 text-[10px] line-clamp-2 mt-0.5 leading-snug">{contact.description}</p>
                  
                  <div className="flex justify-between items-center mt-2.5 pt-2 border-t border-gray-50 text-[10px] text-gray-400">
                    <span className="truncate max-w-[150px]">🗺️ {contact.location || contact.state}</span>
                    <span className="font-bold text-gray-600 font-mono">{contact.phone}</span>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-10 px-4">
              <p className="text-gray-400 text-xs font-semibold">No se encontraron centros de apoyo.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
