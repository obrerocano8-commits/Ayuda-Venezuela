const VENEZUELA_COORDINATES: { keywords: string[]; lat: number; lng: number }[] = [
  { keywords: ['caracas', 'capital', 'chacao', 'baruta', 'el hatillo', 'libertador', 'sucre', 'petare', 'miranda', 'guarenas', 'guatire'], lat: 10.5000, lng: -66.9167 },
  { keywords: ['valencia', 'carabobo', 'guacara', 'naguanagua', 'sandiego', 'san diego', 'tocuyito', 'puerto cabello'], lat: 10.1620, lng: -68.0077 },
  { keywords: ['maracaibo', 'zulia', 'cabimas', 'san francisco', 'lagunillas', 'ciudad ojeda'], lat: 10.6667, lng: -71.6371 },
  { keywords: ['barquisimeto', 'lara', 'cabudare', 'carora', 'el tocuyo'], lat: 10.0681, lng: -69.3496 },
  { keywords: ['maracay', 'aragua', 'cagua', 'turmero', 'la victoria', 'el limon', 'el limón'], lat: 10.2442, lng: -67.6067 },
  { keywords: ['barcelona', 'puerto la cruz', 'anzoategui', 'anzoátegui', 'lecheria', 'lechería', 'el tigre', 'anaco'], lat: 10.1347, lng: -64.6853 },
  { keywords: ['ciudad guayana', 'pzo', 'puerto ordaz', 'bolivar', 'bolívar', 'san felix', 'san félix', 'upata', 'ciudad bolivar'], lat: 8.1222, lng: -63.5497 },
  { keywords: ['san cristobal', 'san cristóbal', 'tachira', 'táchira', 'rubio', 'tariba', 'táriba', 'san antonio'], lat: 7.7669, lng: -72.2250 },
  { keywords: ['merida', 'mérida', 'ejido', 'el vigia', 'el vigía', 'tovar'], lat: 8.5983, lng: -71.1449 },
  { keywords: ['coro', 'falcon', 'falcón', 'punto fijo', 'carirubana'], lat: 11.4084, lng: -69.6775 },
  { keywords: ['cumana', 'cumaná', 'sucre', 'carupano', 'carúpano'], lat: 10.4533, lng: -64.1825 },
  { keywords: ['maturin', 'maturín', 'monagas', 'punta de mata'], lat: 9.7457, lng: -63.1758 },
  { keywords: ['guanare', 'portuguesa', 'acarigua', 'araure'], lat: 9.0418, lng: -69.7421 },
  { keywords: ['barinas', 'pedraza', 'socopo', 'socopó'], lat: 8.6226, lng: -70.2075 },
  { keywords: ['trujillo', 'valera', 'bocono', 'boconó'], lat: 9.3701, lng: -70.4347 },
  { keywords: ['san felipe', 'yaracuy', 'yuritaji', 'chivacoa'], lat: 10.3394, lng: -68.7419 },
  { keywords: ['margarita', 'nueva esparta', 'asuncion', 'asunción', 'porlamar', 'pampatar', 'juan griego'], lat: 11.0333, lng: -63.8628 },
  { keywords: ['san fernando', 'apure', 'elorza', 'guasdualito'], lat: 7.8878, lng: -67.4724 },
  { keywords: ['san juan', 'guarico', 'guárico', 'valle de la pascua', 'calabozo'], lat: 9.9111, lng: -67.3536 },
  { keywords: ['san carlos', 'cojedes', 'tinaquillo'], lat: 9.6612, lng: -68.5827 },
  { keywords: ['tucupita', 'delta amacuro'], lat: 9.0622, lng: -62.0511 },
  { keywords: ['puerto ayacucho', 'amazonas'], lat: 5.6639, lng: -67.6258 },
  { keywords: ['la guaira', 'vargas', 'catia la mar', 'macuto', 'maiquetia', 'maquetía', 'caraballeda'], lat: 10.6012, lng: -66.9322 }
];

export function geocodeVenezuelaLocation(locationStr: string): { lat: number; lng: number } {
  if (!locationStr) {
    return { lat: 10.2 + (Math.random() - 0.5) * 0.1, lng: -67.5 + (Math.random() - 0.5) * 0.1 };
  }
  
  const normalized = locationStr
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
  
  for (const item of VENEZUELA_COORDINATES) {
    for (const keyword of item.keywords) {
      if (normalized.includes(keyword)) {
        // Apply slight random jitter to prevent perfect overlap
        const jitterLat = (Math.random() - 0.5) * 0.04;
        const jitterLng = (Math.random() - 0.5) * 0.04;
        return {
          lat: item.lat + jitterLat,
          lng: item.lng + jitterLng
        };
      }
    }
  }

  // Fallback to approximate center of Venezuela (with jitter)
  const baseLat = 10.2;
  const baseLng = -67.5;
  const jitterLat = (Math.random() - 0.5) * 0.15;
  const jitterLng = (Math.random() - 0.5) * 0.15;
  return {
    lat: baseLat + jitterLat,
    lng: baseLng + jitterLng
  };
}
