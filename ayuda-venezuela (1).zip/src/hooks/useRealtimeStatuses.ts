import { useState, useEffect } from 'react';
import { collectionGroup, query, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';

export interface CenterStatus {
  status: 'Activo' | 'Sin insumos' | 'Cerrado';
  note: string;
  reporterName: string;
  createdAt: string;
  votes: number;
}

export function useRealtimeStatuses() {
  const [statuses, setStatuses] = useState<Record<string, CenterStatus>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Plain collectionGroup query doesn't require any composite index creation
    const q = query(collectionGroup(db, 'novedades'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const allNovedades: Record<string, any[]> = {};
      
      snapshot.forEach((doc) => {
        const data = doc.data();
        const centerId = data.centerId;
        if (!centerId) return;
        
        if (!allNovedades[centerId]) {
          allNovedades[centerId] = [];
        }
        allNovedades[centerId].push({
          id: doc.id,
          ...data
        });
      });

      const computed: Record<string, CenterStatus> = {};
      
      Object.entries(allNovedades).forEach(([centerId, list]) => {
        if (list.length === 0) return;
        
        // Sort by votes desc (masivo), then by date desc (recent) to find highlighted status
        const sorted = [...list].sort((a, b) => {
          if (b.votes !== a.votes) {
            return b.votes - a.votes;
          }
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        });
        
        const top = sorted[0];
        computed[centerId] = {
          status: top.status,
          note: top.note || '',
          reporterName: top.reporterName || 'Ciudadano',
          createdAt: top.createdAt || new Date().toISOString(),
          votes: top.votes || 0
        };
      });

      setStatuses(computed);
      setLoading(false);
    }, (error) => {
      console.error("Error in useRealtimeStatuses collection group listener:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return { statuses, loading };
}
