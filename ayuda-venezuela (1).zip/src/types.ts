export interface UserProfile {
  userId: string;
  displayName: string;
  photoURL: string;
  createdAt: string;
}

export type NovedadStatus = 'activo' | 'sin_insumos' | 'cerrado' | 'recibiendo_donaciones';

export interface NovedadItem {
  id: string;
  status: NovedadStatus;
  details: string;
  createdAt: string;
  reportedBy: string;
  userId: string;
}

export interface CommunityReport {
  id: string;
  userId: string;
  authorName: string;
  authorPhoto: string;
  title: string;
  description: string;
  type: 'need' | 'offer';
  category: 'medicine' | 'food' | 'health_center' | 'legal' | 'shelter' | 'infrastructure' | 'missing_person' | 'other';
  location: string;
  contactInfo: string;
  createdAt: string;
  likesCount: number;
  lat?: number;
  lng?: number;
  currentStatus?: NovedadStatus;
  currentStatusDetails?: string;
  currentStatusAt?: string;
  currentStatusBy?: string;
  isVerified?: boolean;
  verifiedBy?: string;
  verifiedAt?: string;
}

export interface EmergencyContact {
  id: string;
  name: string;
  description: string;
  phone: string;
  category: 'Salud' | 'Alimentos' | 'Servicios' | 'Ayuda Legal';
  location?: string;
  website?: string;
  state?: string;
  lat?: number;
  lng?: number;
}

export interface GuideItem {
  id: string;
  title: string;
  description: string;
  steps: string[];
  category: 'Salud' | 'Electricidad & Agua' | 'Derechos & Legal' | 'Emergencia';
}

export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
  maps?: {
    uri: string;
    title: string;
  };
}

export interface SearchMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  groundingChunks?: GroundingChunk[];
}

export interface GroundingMetadata {
  groundingChunks?: GroundingChunk[];
}

export interface UrgentAlert {
  id: string;
  active: boolean;
  message: string;
  level: 'info' | 'warning' | 'critical';
  updatedAt: string;
  updatedBy: string;
}

