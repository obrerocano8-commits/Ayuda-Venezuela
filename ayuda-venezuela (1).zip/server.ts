import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Port & Host Configuration
const PORT = 3000;
const HOST = '0.0.0.0';

// Lazy-loaded Gemini instance (prevents startup crash if GEMINI_API_KEY is not defined yet)
let aiInstance: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY has not been defined. Please set it in Settings > Secrets.");
    }
    aiInstance = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }
  return aiInstance;
}

// Resilient Fallback System for Quota Limits (RESOURCE_EXHAUSTED / 429) or Network Outages
interface FallbackResource {
  name: string;
  description: string;
  phone: string;
  category: string;
  state: string;
  website?: string;
  keywords: string[];
}

const FALLBACK_RESOURCES: FallbackResource[] = [
  {
    name: 'Cruz Roja Venezolana',
    description: 'Asistencia médica de emergencia, banco de sangre, programas de socorro y respuesta humanitaria.',
    phone: '+58 212-578-2187',
    category: 'Salud',
    state: 'Nacional',
    website: 'http://www.cruzrojavenezolana.org',
    keywords: ['cruz', 'roja', 'medicina', 'insulina', 'sangre', 'salud', 'hospital', 'emergencia', 'medico', 'clinica', 'farmacia', 'doctor']
  },
  {
    name: 'Cáritas de Venezuela',
    description: 'Programa SAMAN de nutrición infantil, entrega de alimentos, medicamentos, y apoyo a comunidades vulnerables.',
    phone: '+58 212-481-0504',
    category: 'Alimentos',
    state: 'Nacional',
    website: 'http://caritasvenezuela.org',
    keywords: ['comida', 'alimento', 'nutricion', 'caritas', 'saman', 'niño', 'hambre', 'vulnerable', 'ayuda social', 'desnutricion', 'almuerzo']
  },
  {
    name: 'Foro Penal (Asistencia Legal)',
    description: 'Asistencia y defensa legal gratuita para personas detenidas arbitrariamente y víctimas de violaciones de DDHH.',
    phone: '+58 412-556-8201',
    category: 'Ayuda Legal',
    state: 'Nacional',
    website: 'https://foropenal.com',
    keywords: ['legal', 'abogado', 'foro penal', 'preso', 'detenido', 'derechos', 'ddhh', 'denuncia', 'defensa', 'presos', 'detencion', 'tribunal']
  },
  {
    name: 'Acción Solidaria',
    description: 'Centro de Información Nacional de VIH/Sida y enfermedades crónicas. Banco de medicamentos y asesoría médica.',
    phone: '+58 212-952-9554',
    category: 'Salud',
    state: 'Caracas',
    website: 'https://www.accionsolidaria.info',
    keywords: ['accion solidaria', 'vih', 'sida', 'cronico', 'medicamento', 'insumo', 'caracas', 'tratamiento', 'farmacia']
  },
  {
    name: 'Bomberos Metropolitanos de Caracas',
    description: 'Cuerpo de bomberos principal para atención de incendios, rescates y emergencias civiles.',
    phone: '+58 212-545-4545',
    category: 'Servicios',
    state: 'Caracas',
    keywords: ['bomberos', 'fuego', 'incendio', 'caracas', 'emergencia', 'rescate', 'accidente', 'bombero', 'ambulancia']
  },
  {
    name: 'PROVEA (Programa de Educación-Acción en DDHH)',
    description: 'Asesoría jurídica gratuita, documentación y defensa de derechos económicos, sociales y culturales.',
    phone: '+58 212-860-6667',
    category: 'Ayuda Legal',
    state: 'Nacional',
    website: 'https://provea.org',
    keywords: ['provea', 'ddhh', 'derechos', 'sociales', 'denuncia', 'asesoria', 'legal', 'abogado', 'educacion']
  },
  {
    name: 'Dividendo Voluntario para la Comunidad (DVC)',
    description: 'Programas de alimentación escolar, comedores comunitarios y salud preventiva para niños y madres.',
    phone: '+58 212-953-2286',
    category: 'Alimentos',
    state: 'Nacional',
    website: 'https://www.dividendovoluntario.org',
    keywords: ['comedor', 'colegio', 'niño', 'comida', 'alimentacion', 'dividendo', 'dvc', 'comunidad']
  },
  {
    name: 'SenosAyuda',
    description: 'Organización de apoyo integral a pacientes con cáncer de mama, mamografías a bajo costo y orientación.',
    phone: '+58 212-993-9892',
    category: 'Salud',
    state: 'Caracas',
    website: 'https://senosayuda.org.ve',
    keywords: ['senosayuda', 'cancer', 'mama', 'seno', 'mastologia', 'mujer', 'mamografia', 'quimio', 'oncologia']
  },
  {
    name: 'Protección Civil y Administración de Desastres',
    description: 'Coordinación nacional para emergencias por lluvias, desastres naturales y ayuda humanitaria de rescate.',
    phone: '+58 212-631-1507',
    category: 'Servicios',
    state: 'Nacional',
    keywords: ['proteccion civil', 'lluvias', 'desastre', 'derrumbe', 'inundacion', 'sismo', 'temblor', 'rescate', 'lluvia', 'riesgo']
  }
];

function generateFallbackResponse(prompt: string, errorMsg: string) {
  const normalizedPrompt = prompt.toLowerCase();
  
  // Find matched resources
  let matched = FALLBACK_RESOURCES.filter(res => {
    return res.keywords.some(keyword => normalizedPrompt.includes(keyword)) ||
           res.name.toLowerCase().includes(normalizedPrompt) ||
           res.category.toLowerCase().includes(normalizedPrompt) ||
           res.state.toLowerCase().includes(normalizedPrompt);
  });

  // If no matches, default to top general emergency/help organizations
  if (matched.length === 0) {
    matched = FALLBACK_RESOURCES.slice(0, 4); // Cruz Roja, Cáritas, Foro Penal, Acción Solidaria
  }

  // Build markdown text
  let text = `⚠️ **Asistente de Respaldo Local (IA Temporalmente no disponible)**\n\n`;
  text += `El buscador con Inteligencia Artificial no está disponible en este momento debido a un límite de consultas de cuota en el servidor o a una saturación temporal de la red.\n\n`;
  text += `Para garantizar tu asistencia inmediata y que nunca te quedes sin opciones, he activado nuestro **motor de respuestas locales**. Basado en tu consulta: *"${prompt}"*, hemos seleccionado los siguientes contactos esenciales directos:\n\n`;

  matched.forEach(res => {
    text += `### 🏢 ${res.name} (${res.state})\n`;
    text += `* **Categoría:** \`${res.category}\`\n`;
    text += `* **Descripción:** ${res.description}\n`;
    text += `* **Contacto Directo:** 📞 **${res.phone}**\n`;
    if (res.website) {
      text += `* **Sitio Web:** [${res.website}](${res.website})\n`;
    }
    text += `\n---\n\n`;
  });

  text += `💡 *Consejo:* Puedes navegar al **Directorio de Apoyo** en la pestaña de arriba para consultar el catálogo completo de instituciones nacionales y regionales, buscar por palabras clave o guardar tus contactos favoritos para tenerlos siempre a la mano sin conexión.`;

  // Format grounding chunks
  const groundingChunks = matched.map(res => {
    if (res.website) {
      return {
        web: {
          title: res.name,
          uri: res.website
        }
      };
    } else {
      return {
        maps: {
          title: `${res.name} - ${res.state}`,
          uri: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(res.name + ' ' + res.state + ' Venezuela')}`
        }
      };
    }
  });

  return {
    text,
    groundingChunks,
    isFallback: true
  };
}

async function startServer() {
  const app = express();

  // Middleware
  app.use(express.json());

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Proxy route for Gemini Search & Maps Grounding
  app.post('/api/assist', async (req, res) => {
    const { prompt, type, latLng } = req.body;

    if (!prompt) {
      res.status(400).json({ error: "Se requiere un prompt para la consulta." });
      return;
    }

    try {
      const ai = getGeminiClient();
      
      let tools: any[] = [];
      let toolConfig: any = undefined;

      if (type === 'maps') {
        tools = [{ googleMaps: {} }];
        if (latLng && typeof latLng.latitude === 'number' && typeof latLng.longitude === 'number') {
          toolConfig = {
            retrievalConfig: {
              latLng: {
                latitude: latLng.latitude,
                longitude: latLng.longitude
              }
            }
          };
        } else {
          // Default coordinate centering in Caracas, Venezuela
          toolConfig = {
            retrievalConfig: {
              latLng: {
                latitude: 10.4806,
                longitude: -66.9036
              }
            }
          };
        }
      } else {
        // Default is search grounding
        tools = [{ googleSearch: {} }];
      }

      // Prepend context guidelines to the prompt so that Gemini answers specifically about Venezuela resources
      const systemContext = "Estás actuando como un asistente humanitario experto para la plataforma 'Ayuda Venezuela'. Tu misión es ayudar a la gente a encontrar alimentos, medicinas, centros de salud, asistencia legal, refugio y otros recursos esenciales en Venezuela. Tu respuesta debe ser clara, comprensiva, redactada en español y de forma empática. Si usas Google Maps o Google Search, guía al usuario sobre dónde buscar físicamente o qué páginas web visitar.";
      
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `${systemContext}\n\nConsulta del usuario: ${prompt}`,
        config: {
          tools,
          toolConfig,
        }
      });

      const text = response.text || "No se pudo generar respuesta de texto.";
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

      res.json({
        text,
        groundingChunks: chunks
      });
    } catch (error: any) {
      console.error("Error in Gemini integration, executing local fallback:", error);
      
      const fallback = generateFallbackResponse(prompt, error.message || String(error));
      res.json(fallback);
    }
  });

  // Serve Frontend
  if (process.env.NODE_ENV !== 'production') {
    // Development Mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production Mode
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Start listening
  app.listen(PORT, HOST, () => {
    console.log(`Server running in ${process.env.NODE_ENV || 'development'} mode on http://${HOST}:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
