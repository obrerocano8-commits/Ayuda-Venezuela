const CACHE_NAME = 'ayuda-vzla-offline-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/src/main.tsx',
  '/src/index.css',
  '/src/App.tsx'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[Service Worker] Pre-caching offline shell');
      return cache.addAll(ASSETS_TO_CACHE).catch(err => {
        console.warn('[Service Worker] Pre-cache failed (some files might be bundled differently):', err);
      });
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('[Service Worker] Removing old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);

  // Only intercept GET requests of local files or Google Fonts
  if (request.method !== 'GET') {
    return;
  }

  // Allow Firestore / Google Auth to pass through or use their own caching
  if (url.hostname.includes('firestore.googleapis.com') || url.hostname.includes('googleapis.com') || url.hostname.includes('securetoken.googleapis.com')) {
    return;
  }

  // Network-First with Fallback to Cache
  event.respondWith(
    fetch(request)
      .then((networkResponse) => {
        // Only cache successful requests of local origin or fonts
        if (networkResponse && networkResponse.status === 200 && (url.origin === self.location.origin || url.hostname.includes('fonts.'))) {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(request, responseToCache);
          });
        }
        return networkResponse;
      })
      .catch(() => {
        console.log('[Service Worker] Network request failed. Serving from cache:', request.url);
        return caches.match(request).then((cachedResponse) => {
          if (cachedResponse) {
            return cachedResponse;
          }
          
          // For HTML navigation requests, return the cached index.html
          if (request.mode === 'navigate' || (request.headers.get('accept') && request.headers.get('accept').includes('text/html'))) {
            return caches.match('/index.html') || caches.match('/');
          }
          
          return null;
        });
      })
  );
});
